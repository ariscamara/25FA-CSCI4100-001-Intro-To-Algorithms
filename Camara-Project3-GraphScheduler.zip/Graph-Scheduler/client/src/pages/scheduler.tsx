import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { ThemeToggle } from "@/components/theme-toggle";
import { GraphVisualization } from "@/components/graph-visualization";
import { CourseForm } from "@/components/course-form";
import { ConflictForm } from "@/components/conflict-form";
import { CourseList } from "@/components/course-list";
import { ScheduleTable } from "@/components/schedule-table";
import { RoomAllocation } from "@/components/room-allocation";
import { ConflictsList } from "@/components/conflicts-list";
import { RoomForm } from "@/components/room-form";
import { StatisticsPanel } from "@/components/statistics-panel";
import { SemesterSelector } from "@/components/semester-selector";
import {
  Play,
  RotateCcw,
  Network,
  Calendar,
  Building,
  Sparkles,
  Loader2,
  AlertTriangle,
  Download,
  FileText,
  BookOpen,
  GraduationCap,
} from "lucide-react";
import { exportScheduleToCSV, exportScheduleToPDF } from "@/lib/export-utils";
import type {
  Course,
  Conflict,
  Room,
  ScheduleResult,
  InsertCourse,
  InsertConflict,
  InsertRoom,
  AlgorithmType,
} from "@shared/schema";

export default function Scheduler() {
  const { toast } = useToast();
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [activeTab, setActiveTab] = useState("graph");
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<AlgorithmType>("greedy");

  const { data: courses = [], isLoading: coursesLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: conflicts = [], isLoading: conflictsLoading } = useQuery<Conflict[]>({
    queryKey: ["/api/conflicts"],
  });

  const { data: rooms = [], isLoading: roomsLoading } = useQuery<Room[]>({
    queryKey: ["/api/rooms"],
  });

  const { data: scheduleResult } = useQuery<ScheduleResult | null>({
    queryKey: ["/api/schedule"],
  });

  const addCourseMutation = useMutation({
    mutationFn: async (data: InsertCourse) => {
      return apiRequest("POST", "/api/courses", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({ title: "Course added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add course", variant: "destructive" });
    },
  });

  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: InsertCourse }) => {
      return apiRequest("PATCH", `/api/courses/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setEditingCourse(null);
      toast({ title: "Course updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update course", variant: "destructive" });
    },
  });

  const deleteCourseMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conflicts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      toast({ title: "Course deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete course", variant: "destructive" });
    },
  });

  const addConflictMutation = useMutation({
    mutationFn: async (data: InsertConflict) => {
      return apiRequest("POST", "/api/conflicts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conflicts"] });
      toast({ title: "Conflict added" });
    },
    onError: () => {
      toast({ title: "Failed to add conflict", variant: "destructive" });
    },
  });

  const deleteConflictMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/conflicts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conflicts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      toast({ title: "Conflict deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete conflict", variant: "destructive" });
    },
  });

  const addRoomMutation = useMutation({
    mutationFn: async (data: InsertRoom) => {
      return apiRequest("POST", "/api/rooms", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      toast({ title: "Room added" });
    },
    onError: () => {
      toast({ title: "Failed to add room", variant: "destructive" });
    },
  });

  const generateScheduleMutation = useMutation({
    mutationFn: async (algorithm: AlgorithmType): Promise<ScheduleResult> => {
      const response = await apiRequest("POST", "/api/schedule/generate", { algorithm });
      return response.json();
    },
    onSuccess: (result: ScheduleResult) => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      const algorithmName = {
        greedy: "Greedy",
        "welsh-powell": "Welsh-Powell",
        dsatur: "DSatur",
        backtracking: "Backtracking",
      }[result.algorithm || "greedy"];
      
      if (result.validationErrors && result.validationErrors.length > 0) {
        toast({
          title: "Schedule generated with warnings",
          description: `${algorithmName} algorithm completed in ${result.executionTimeMs}ms. ${result.validationErrors.length} constraint violation(s) found.`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Schedule generated!",
          description: `${algorithmName} algorithm completed in ${result.executionTimeMs}ms using ${result.chromaticNumber} time slots.`,
        });
      }
    },
    onError: () => {
      toast({ title: "Failed to generate schedule", variant: "destructive" });
    },
  });

  const resetScheduleMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/schedule/reset");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      toast({ title: "Schedule reset" });
    },
    onError: () => {
      toast({ title: "Failed to reset schedule", variant: "destructive" });
    },
  });

  const loadExampleMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/example");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conflicts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      toast({
        title: "Example data loaded",
        description: "6 courses, 6 conflicts, and 4 rooms have been added.",
      });
    },
    onError: () => {
      toast({ title: "Failed to load example", variant: "destructive" });
    },
  });

  const handleCourseSubmit = (data: InsertCourse) => {
    if (editingCourse) {
      updateCourseMutation.mutate({ id: editingCourse.id, data });
    } else {
      addCourseMutation.mutate(data);
    }
  };

  const isLoading = coursesLoading || conflictsLoading || roomsLoading;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <Network className="h-6 w-6 text-primary" />
              <div>
                <h1 className="text-xl font-bold">GraphScheduler</h1>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Course scheduling with graph coloring
                </p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-1 ml-2">
              <Link href="/docs">
                <Button variant="ghost" size="sm" data-testid="link-docs">
                  <BookOpen className="h-4 w-4 mr-1.5" />
                  Docs
                </Button>
              </Link>
              <Link href="/academic-guide">
                <Button variant="ghost" size="sm" data-testid="link-academic-guide">
                  <GraduationCap className="h-4 w-4 mr-1.5" />
                  Academic Guide
                </Button>
              </Link>
              <Link href="/release-notes">
                <Button variant="ghost" size="sm" data-testid="link-release-notes">
                  <FileText className="h-4 w-4 mr-1.5" />
                  Release Notes
                </Button>
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            <SemesterSelector />
            <div className="w-px h-6 bg-border hidden sm:block" />
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadExampleMutation.mutate()}
              disabled={loadExampleMutation.isPending}
              data-testid="button-load-example"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Load Example
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => resetScheduleMutation.mutate()}
              disabled={resetScheduleMutation.isPending}
              data-testid="button-reset"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            <Select
              value={selectedAlgorithm}
              onValueChange={(value) => setSelectedAlgorithm(value as AlgorithmType)}
            >
              <SelectTrigger className="w-[140px] h-8" data-testid="select-algorithm">
                <SelectValue placeholder="Algorithm" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="greedy">Greedy</SelectItem>
                <SelectItem value="welsh-powell">Welsh-Powell</SelectItem>
                <SelectItem value="dsatur">DSatur</SelectItem>
                <SelectItem value="backtracking">Backtracking</SelectItem>
              </SelectContent>
            </Select>
            <Button
              size="sm"
              onClick={() => generateScheduleMutation.mutate(selectedAlgorithm)}
              disabled={generateScheduleMutation.isPending || courses.length === 0}
              data-testid="button-generate"
            >
              {generateScheduleMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Play className="h-4 w-4 mr-2" />
              )}
              Generate
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="space-y-6">
          <StatisticsPanel
            courses={courses}
            conflicts={conflicts}
            rooms={rooms}
            scheduleResult={scheduleResult || null}
          />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 space-y-4">
              <CourseForm
                onSubmit={handleCourseSubmit}
                editingCourse={editingCourse}
                onCancel={editingCourse ? () => setEditingCourse(null) : undefined}
                isPending={addCourseMutation.isPending || updateCourseMutation.isPending}
              />

              <ConflictForm
                courses={courses}
                onSubmit={(data) => addConflictMutation.mutate(data)}
                isPending={addConflictMutation.isPending}
              />

              <RoomForm
                onSubmit={(data) => addRoomMutation.mutate(data)}
                isPending={addRoomMutation.isPending}
              />
            </div>

            <div className="lg:col-span-8 space-y-4">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="graph" data-testid="tab-graph">
                    <Network className="h-4 w-4 mr-2" />
                    Graph View
                  </TabsTrigger>
                  <TabsTrigger value="schedule" data-testid="tab-schedule">
                    <Calendar className="h-4 w-4 mr-2" />
                    Schedule
                  </TabsTrigger>
                  <TabsTrigger value="rooms" data-testid="tab-rooms">
                    <Building className="h-4 w-4 mr-2" />
                    Room Matrix
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="graph" className="mt-4">
                  <div className="h-[600px]">
                    <GraphVisualization
                      courses={courses}
                      conflicts={conflicts}
                      assignments={scheduleResult?.assignments || []}
                      onSelectCourse={setSelectedCourse}
                      selectedCourseId={selectedCourse?.id || null}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="schedule" className="mt-4">
                  {scheduleResult && scheduleResult.assignments.length > 0 && (
                    <div className="flex items-center justify-end gap-2 mb-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportScheduleToCSV(scheduleResult, courses, rooms)}
                        data-testid="button-export-csv"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Export CSV
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportScheduleToPDF(scheduleResult, courses, rooms)}
                        data-testid="button-export-pdf"
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Print / PDF
                      </Button>
                    </div>
                  )}
                  <ScheduleTable
                    courses={courses}
                    rooms={rooms}
                    scheduleResult={scheduleResult || null}
                  />
                </TabsContent>

                <TabsContent value="rooms" className="mt-4">
                  <RoomAllocation
                    courses={courses}
                    rooms={rooms}
                    scheduleResult={scheduleResult || null}
                  />
                </TabsContent>
              </Tabs>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CourseList
              courses={courses}
              conflicts={conflicts}
              assignments={scheduleResult?.assignments || []}
              selectedCourseId={selectedCourse?.id || null}
              onSelectCourse={setSelectedCourse}
              onEditCourse={setEditingCourse}
              onDeleteCourse={(id) => deleteCourseMutation.mutate(id)}
            />

            <ConflictsList
              courses={courses}
              conflicts={conflicts}
              onDeleteConflict={(id) => deleteConflictMutation.mutate(id)}
            />
          </div>
        </div>
      </main>

      <footer className="border-t py-4 mt-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          Graph Coloring for Course Scheduling - Greedy Algorithm Implementation
        </div>
      </footer>
    </div>
  );
}
