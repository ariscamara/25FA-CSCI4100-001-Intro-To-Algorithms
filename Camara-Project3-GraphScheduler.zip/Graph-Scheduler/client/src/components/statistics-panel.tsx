import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Link2, Clock, Building, CheckCircle2, AlertTriangle, Zap } from "lucide-react";
import type { Course, Conflict, Room, ScheduleResult } from "@shared/schema";

interface StatisticsPanelProps {
  courses: Course[];
  conflicts: Conflict[];
  rooms: Room[];
  scheduleResult: ScheduleResult | null;
}

export function StatisticsPanel({
  courses,
  conflicts,
  rooms,
  scheduleResult,
}: StatisticsPanelProps) {
  const algorithmNames: Record<string, string> = {
    greedy: "Greedy",
    "welsh-powell": "Welsh-Powell",
    dsatur: "DSatur",
    backtracking: "Backtracking",
  };

  const stats = [
    {
      label: "Courses",
      value: courses.length,
      icon: BookOpen,
      color: "text-chart-1",
    },
    {
      label: "Conflicts",
      value: conflicts.length,
      icon: Link2,
      color: "text-chart-2",
    },
    {
      label: "Rooms",
      value: rooms.length,
      icon: Building,
      color: "text-chart-3",
    },
    {
      label: "Time Slots",
      value: scheduleResult?.totalTimeSlots || 0,
      icon: Clock,
      color: "text-chart-4",
    },
  ];

  const hasValidationErrors = scheduleResult?.validationErrors && scheduleResult.validationErrors.length > 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="relative overflow-visible">
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold font-mono mt-1" data-testid={`stat-${stat.label.toLowerCase()}`}>
                    {stat.value}
                  </p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color} opacity-80`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {scheduleResult && scheduleResult.chromaticNumber > 0 && (
        <Card className={`${hasValidationErrors ? "bg-destructive/5 border-destructive/20" : "bg-primary/5 border-primary/20"}`}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {hasValidationErrors ? (
                <AlertTriangle className="h-6 w-6 text-destructive mt-0.5" />
              ) : (
                <CheckCircle2 className="h-6 w-6 text-primary mt-0.5" />
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-medium" data-testid="schedule-status">
                    {hasValidationErrors ? "Schedule Generated with Warnings" : "Schedule Generated Successfully"}
                  </p>
                  {scheduleResult.algorithm && (
                    <Badge variant="secondary" className="text-xs">
                      {algorithmNames[scheduleResult.algorithm] || scheduleResult.algorithm}
                    </Badge>
                  )}
                  {scheduleResult.executionTimeMs !== undefined && (
                    <Badge variant="outline" className="text-xs gap-1">
                      <Zap className="h-3 w-3" />
                      {scheduleResult.executionTimeMs}ms
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Chromatic number: {scheduleResult.chromaticNumber} (minimum colors needed)
                </p>
                
                {hasValidationErrors && (
                  <div className="mt-3 space-y-1">
                    <p className="text-sm font-medium text-destructive">Constraint Violations:</p>
                    {scheduleResult.validationErrors?.map((error, idx) => (
                      <p key={idx} className="text-sm text-muted-foreground pl-2 border-l-2 border-destructive/30">
                        {error}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
