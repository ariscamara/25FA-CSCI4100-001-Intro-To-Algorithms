import { z } from "zod";

export const conflictTypes = ["same_professor", "same_room", "same_students", "same_timeslot", "prerequisite"] as const;
export type ConflictType = typeof conflictTypes[number];

export const courseSchema = z.object({
  id: z.string(),
  code: z.string().min(1, "Course code is required"),
  name: z.string().min(1, "Course name is required"),
  professor: z.string().optional(),
  students: z.array(z.string()).default([]),
  preferredRoom: z.string().optional(),
});

export const insertCourseSchema = courseSchema.omit({ id: true });
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = z.infer<typeof courseSchema>;

export const conflictSchema = z.object({
  id: z.string(),
  course1Id: z.string(),
  course2Id: z.string(),
  type: z.enum(conflictTypes),
});

export const insertConflictSchema = conflictSchema.omit({ id: true });
export type InsertConflict = z.infer<typeof insertConflictSchema>;
export type Conflict = z.infer<typeof conflictSchema>;

export const roomSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Room name is required"),
  capacity: z.number().min(1).default(30),
});

export const insertRoomSchema = roomSchema.omit({ id: true });
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = z.infer<typeof roomSchema>;

export const scheduleAssignmentSchema = z.object({
  courseId: z.string(),
  timeSlot: z.number(),
  roomId: z.string().optional(),
  color: z.string(),
});

export type ScheduleAssignment = z.infer<typeof scheduleAssignmentSchema>;

export const scheduleResultSchema = z.object({
  assignments: z.array(scheduleAssignmentSchema),
  chromaticNumber: z.number(),
  totalTimeSlots: z.number(),
  algorithm: z.string().optional(),
  executionTimeMs: z.number().optional(),
  validationErrors: z.array(z.string()).optional(),
  topologicalOrder: z.array(z.string()).optional(),
});

export type ScheduleResult = z.infer<typeof scheduleResultSchema>;

export const algorithmTypes = ["greedy", "welsh-powell", "dsatur", "backtracking"] as const;
export type AlgorithmType = typeof algorithmTypes[number];

export function getTimeSlotLabel(slot: number): string {
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  const times = ["8:00-9:30", "9:45-11:15", "11:30-13:00", "14:00-15:30", "15:45-17:15"];
  const dayIndex = Math.floor(slot / times.length);
  const timeIndex = slot % times.length;
  if (dayIndex < days.length) {
    return `${days[dayIndex]} ${times[timeIndex]}`;
  }
  return `Slot ${slot + 1}`;
}

export interface GraphData {
  courses: Course[];
  conflicts: Conflict[];
  rooms: Room[];
}

export interface SchedulerState {
  graphData: GraphData;
  scheduleResult: ScheduleResult | null;
  isGenerating: boolean;
}

export const semesterSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Semester name is required"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  isActive: z.boolean().default(false),
});

export const insertSemesterSchema = z.object({
  name: z.string().min(1, "Semester name is required"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  isActive: z.boolean().optional(),
});
export type InsertSemester = z.infer<typeof insertSemesterSchema>;
export type Semester = z.infer<typeof semesterSchema>;

export const users = {
  $inferSelect: {} as { id: string; username: string; password: string }
};
export type User = typeof users.$inferSelect;
export type InsertUser = { username: string; password: string };
