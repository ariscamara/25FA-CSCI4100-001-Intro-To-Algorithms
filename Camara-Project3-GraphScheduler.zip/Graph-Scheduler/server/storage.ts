import { randomUUID } from "crypto";
import type {
  Course,
  InsertCourse,
  Conflict,
  InsertConflict,
  Room,
  InsertRoom,
  ScheduleResult,
  Semester,
  InsertSemester,
} from "@shared/schema";

export interface IStorage {
  getCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, course: InsertCourse): Promise<Course | undefined>;
  deleteCourse(id: string): Promise<boolean>;

  getConflicts(): Promise<Conflict[]>;
  getConflict(id: string): Promise<Conflict | undefined>;
  createConflict(conflict: InsertConflict): Promise<Conflict>;
  deleteConflict(id: string): Promise<boolean>;
  deleteConflictsByCourse(courseId: string): Promise<void>;

  getRooms(): Promise<Room[]>;
  getRoom(id: string): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  deleteRoom(id: string): Promise<boolean>;

  getScheduleResult(): Promise<ScheduleResult | null>;
  setScheduleResult(result: ScheduleResult | null): Promise<void>;

  getSemesters(): Promise<Semester[]>;
  getSemester(id: string): Promise<Semester | undefined>;
  createSemester(semester: InsertSemester): Promise<Semester>;
  updateSemester(id: string, semester: InsertSemester): Promise<Semester | undefined>;
  deleteSemester(id: string): Promise<boolean>;
  setActiveSemester(id: string): Promise<Semester | undefined>;

  clearAll(): Promise<void>;
}

export class MemStorage implements IStorage {
  private courses: Map<string, Course>;
  private conflicts: Map<string, Conflict>;
  private rooms: Map<string, Room>;
  private scheduleResult: ScheduleResult | null;
  private semesters: Map<string, Semester>;

  constructor() {
    this.courses = new Map();
    this.conflicts = new Map();
    this.rooms = new Map();
    this.scheduleResult = null;
    this.semesters = new Map();
    
    const defaultSemester: Semester = {
      id: randomUUID(),
      name: "Fall 2024",
      isActive: true,
    };
    this.semesters.set(defaultSemester.id, defaultSemester);
  }

  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: string): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = randomUUID();
    const course: Course = {
      id,
      code: insertCourse.code,
      name: insertCourse.name,
      professor: insertCourse.professor,
      students: insertCourse.students || [],
      preferredRoom: insertCourse.preferredRoom,
    };
    this.courses.set(id, course);
    return course;
  }

  async updateCourse(id: string, insertCourse: InsertCourse): Promise<Course | undefined> {
    const existing = this.courses.get(id);
    if (!existing) return undefined;

    const updated: Course = {
      ...existing,
      code: insertCourse.code,
      name: insertCourse.name,
      professor: insertCourse.professor,
      students: insertCourse.students || [],
      preferredRoom: insertCourse.preferredRoom,
    };
    this.courses.set(id, updated);
    return updated;
  }

  async deleteCourse(id: string): Promise<boolean> {
    return this.courses.delete(id);
  }

  async getConflicts(): Promise<Conflict[]> {
    return Array.from(this.conflicts.values());
  }

  async getConflict(id: string): Promise<Conflict | undefined> {
    return this.conflicts.get(id);
  }

  async createConflict(insertConflict: InsertConflict): Promise<Conflict> {
    const id = randomUUID();
    const conflict: Conflict = {
      id,
      course1Id: insertConflict.course1Id,
      course2Id: insertConflict.course2Id,
      type: insertConflict.type,
    };
    this.conflicts.set(id, conflict);
    return conflict;
  }

  async deleteConflict(id: string): Promise<boolean> {
    return this.conflicts.delete(id);
  }

  async deleteConflictsByCourse(courseId: string): Promise<void> {
    for (const [id, conflict] of Array.from(this.conflicts.entries())) {
      if (conflict.course1Id === courseId || conflict.course2Id === courseId) {
        this.conflicts.delete(id);
      }
    }
  }

  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = randomUUID();
    const room: Room = {
      id,
      name: insertRoom.name,
      capacity: insertRoom.capacity,
    };
    this.rooms.set(id, room);
    return room;
  }

  async deleteRoom(id: string): Promise<boolean> {
    return this.rooms.delete(id);
  }

  async getScheduleResult(): Promise<ScheduleResult | null> {
    return this.scheduleResult;
  }

  async setScheduleResult(result: ScheduleResult | null): Promise<void> {
    this.scheduleResult = result;
  }

  async getSemesters(): Promise<Semester[]> {
    return Array.from(this.semesters.values());
  }

  async getSemester(id: string): Promise<Semester | undefined> {
    return this.semesters.get(id);
  }

  async createSemester(insertSemester: InsertSemester): Promise<Semester> {
    const id = randomUUID();
    const semester: Semester = {
      id,
      name: insertSemester.name,
      startDate: insertSemester.startDate,
      endDate: insertSemester.endDate,
      isActive: insertSemester.isActive ?? false,
    };
    this.semesters.set(id, semester);
    return semester;
  }

  async updateSemester(id: string, insertSemester: InsertSemester): Promise<Semester | undefined> {
    const existing = this.semesters.get(id);
    if (!existing) return undefined;

    const updated: Semester = {
      ...existing,
      name: insertSemester.name,
      startDate: insertSemester.startDate,
      endDate: insertSemester.endDate,
      isActive: insertSemester.isActive ?? existing.isActive,
    };
    this.semesters.set(id, updated);
    return updated;
  }

  async deleteSemester(id: string): Promise<boolean> {
    return this.semesters.delete(id);
  }

  async setActiveSemester(id: string): Promise<Semester | undefined> {
    const semester = this.semesters.get(id);
    if (!semester) return undefined;

    for (const [key, s] of Array.from(this.semesters.entries())) {
      this.semesters.set(key, { ...s, isActive: key === id });
    }
    return { ...semester, isActive: true };
  }

  async clearAll(): Promise<void> {
    this.courses.clear();
    this.conflicts.clear();
    this.rooms.clear();
    this.scheduleResult = null;
  }
}

export const storage = new MemStorage();
