import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Plus, X, BookOpen, Save } from "lucide-react";
import { insertCourseSchema, type InsertCourse, type Course } from "@shared/schema";

interface CourseFormProps {
  onSubmit: (data: InsertCourse) => void;
  onCancel?: () => void;
  editingCourse?: Course | null;
  isPending?: boolean;
}

export function CourseForm({ onSubmit, onCancel, editingCourse, isPending }: CourseFormProps) {
  const form = useForm<InsertCourse>({
    resolver: zodResolver(insertCourseSchema),
    defaultValues: {
      code: "",
      name: "",
      professor: "",
      students: [],
      preferredRoom: "",
    },
  });

  useEffect(() => {
    if (editingCourse) {
      form.reset({
        code: editingCourse.code,
        name: editingCourse.name,
        professor: editingCourse.professor || "",
        students: editingCourse.students || [],
        preferredRoom: editingCourse.preferredRoom || "",
      });
    } else {
      form.reset({
        code: "",
        name: "",
        professor: "",
        students: [],
        preferredRoom: "",
      });
    }
  }, [editingCourse, form]);

  const handleSubmit = (data: InsertCourse) => {
    onSubmit(data);
    if (!editingCourse) {
      form.reset();
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">
            {editingCourse ? "Edit Course" : "Add Course"}
          </CardTitle>
        </div>
        {onCancel && (
          <Button size="icon" variant="ghost" onClick={onCancel} data-testid="button-cancel-form">
            <X className="h-4 w-4" />
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Course Code</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="CS101"
                        {...field}
                        data-testid="input-course-code"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="professor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Professor</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Dr. Smith"
                        {...field}
                        data-testid="input-professor"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Course Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Introduction to Computer Science"
                      {...field}
                      data-testid="input-course-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="preferredRoom"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Preferred Room (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Room 101"
                      {...field}
                      data-testid="input-preferred-room"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-2 pt-2">
              {onCancel && (
                <Button type="button" variant="outline" onClick={onCancel} data-testid="button-cancel-edit">
                  Cancel
                </Button>
              )}
              <Button type="submit" disabled={isPending} data-testid="button-submit-course">
                {editingCourse ? (
                  <Save className="h-4 w-4 mr-2" />
                ) : (
                  <Plus className="h-4 w-4 mr-2" />
                )}
                {editingCourse ? "Update Course" : "Add Course"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
