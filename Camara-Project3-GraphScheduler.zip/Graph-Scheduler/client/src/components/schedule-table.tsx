import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Calendar, Clock, MapPin, User, CheckCircle2 } from "lucide-react";
import type { Course, Room, ScheduleAssignment, ScheduleResult } from "@shared/schema";
import { getColorForTimeSlot } from "@/lib/graph-colors";

interface ScheduleTableProps {
  courses: Course[];
  rooms: Room[];
  scheduleResult: ScheduleResult | null;
}

export function ScheduleTable({ courses, rooms, scheduleResult }: ScheduleTableProps) {
  if (!scheduleResult || scheduleResult.assignments.length === 0) {
    return (
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center gap-2 pb-4">
          <Calendar className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Schedule</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center h-48 text-center">
            <Calendar className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground text-lg font-medium">No schedule generated</p>
            <p className="text-muted-foreground/70 text-sm mt-1">
              Add courses and conflicts, then generate a schedule
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getCourse = (courseId: string) => courses.find((c) => c.id === courseId);
  const getRoom = (roomId?: string) => rooms.find((r) => r.id === roomId);

  const sortedAssignments = [...scheduleResult.assignments].sort(
    (a, b) => a.timeSlot - b.timeSlot
  );

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Course Schedule</CardTitle>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="gap-1">
            <CheckCircle2 className="h-3 w-3" />
            {scheduleResult.chromaticNumber} time slots
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-[400px]">
          <Table>
            <TableHeader className="sticky top-0 bg-card z-10">
              <TableRow>
                <TableHead className="w-24">Course</TableHead>
                <TableHead className="w-32">Name</TableHead>
                <TableHead className="w-24">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Time Slot
                  </div>
                </TableHead>
                <TableHead className="w-24">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    Room
                  </div>
                </TableHead>
                <TableHead>
                  <div className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    Professor
                  </div>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedAssignments.map((assignment) => {
                const course = getCourse(assignment.courseId);
                const room = getRoom(assignment.roomId);
                const color = getColorForTimeSlot(assignment.timeSlot);

                if (!course) return null;

                return (
                  <TableRow key={assignment.courseId} data-testid={`schedule-row-${course.id}`}>
                    <TableCell>
                      <span className="font-mono font-semibold">{course.code}</span>
                    </TableCell>
                    <TableCell className="text-muted-foreground truncate max-w-[200px]">
                      {course.name}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className="font-mono"
                        style={{
                          backgroundColor: color.bg,
                          color: color.text,
                          borderColor: color.bg,
                        }}
                      >
                        Slot {assignment.timeSlot}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {room ? (
                        <span className="font-mono text-sm">{room.name}</span>
                      ) : (
                        <span className="text-muted-foreground text-sm">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {course.professor || "-"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
