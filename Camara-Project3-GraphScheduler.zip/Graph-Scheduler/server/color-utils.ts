const TIME_SLOT_COLORS = [
  "hsl(217, 91%, 48%)",
  "hsl(142, 76%, 36%)",
  "hsl(262, 83%, 58%)",
  "hsl(32, 95%, 44%)",
  "hsl(340, 82%, 52%)",
  "hsl(180, 70%, 35%)",
  "hsl(45, 93%, 47%)",
  "hsl(0, 84%, 42%)",
  "hsl(280, 65%, 45%)",
  "hsl(200, 80%, 40%)",
];

export function getColorForTimeSlot(timeSlot: number): string {
  return TIME_SLOT_COLORS[timeSlot % TIME_SLOT_COLORS.length];
}
