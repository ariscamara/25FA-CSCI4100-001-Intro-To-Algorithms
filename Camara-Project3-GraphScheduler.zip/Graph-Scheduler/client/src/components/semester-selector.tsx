import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { GraduationCap, Plus, Trash2 } from "lucide-react";
import type { Semester, InsertSemester } from "@shared/schema";

export function SemesterSelector() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newSemesterName, setNewSemesterName] = useState("");

  const { data: semesters = [] } = useQuery<Semester[]>({
    queryKey: ["/api/semesters"],
  });

  const activeSemester = semesters.find((s) => s.isActive);

  const activateMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("POST", `/api/semesters/${id}/activate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/semesters"] });
      toast({ title: "Semester activated" });
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertSemester) => {
      return apiRequest("POST", "/api/semesters", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/semesters"] });
      setNewSemesterName("");
      setIsDialogOpen(false);
      toast({ title: "Semester created" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/semesters/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/semesters"] });
      toast({ title: "Semester deleted" });
    },
  });

  const handleCreateSemester = () => {
    if (!newSemesterName.trim()) return;
    createMutation.mutate({ name: newSemesterName.trim(), isActive: false });
  };

  return (
    <div className="flex items-center gap-2">
      <GraduationCap className="h-4 w-4 text-muted-foreground" />
      <Select
        value={activeSemester?.id || ""}
        onValueChange={(id) => activateMutation.mutate(id)}
      >
        <SelectTrigger className="w-[140px] h-8" data-testid="select-semester">
          <SelectValue placeholder="Select Semester" />
        </SelectTrigger>
        <SelectContent>
          {semesters.map((semester) => (
            <div key={semester.id} className="flex items-center gap-1">
              <SelectItem value={semester.id} className="flex-1">
                {semester.name}
              </SelectItem>
            </div>
          ))}
        </SelectContent>
      </Select>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button size="icon" variant="ghost" data-testid="button-add-semester">
            <Plus className="h-4 w-4" />
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manage Semesters</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>New Semester Name</Label>
              <div className="flex gap-2">
                <Input
                  value={newSemesterName}
                  onChange={(e) => setNewSemesterName(e.target.value)}
                  placeholder="e.g., Spring 2025"
                  data-testid="input-semester-name"
                />
                <Button
                  onClick={handleCreateSemester}
                  disabled={!newSemesterName.trim() || createMutation.isPending}
                  data-testid="button-create-semester"
                >
                  Add
                </Button>
              </div>
            </div>

            {semesters.length > 0 && (
              <div className="space-y-2">
                <Label>Existing Semesters</Label>
                <div className="space-y-1">
                  {semesters.map((semester) => (
                    <div
                      key={semester.id}
                      className="flex items-center justify-between gap-2 p-2 rounded bg-muted/50"
                    >
                      <span className="text-sm">
                        {semester.name}
                        {semester.isActive && (
                          <span className="ml-2 text-xs text-primary">(Active)</span>
                        )}
                      </span>
                      {!semester.isActive && (
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(semester.id)}
                          disabled={deleteMutation.isPending}
                          data-testid={`button-delete-semester-${semester.id}`}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
