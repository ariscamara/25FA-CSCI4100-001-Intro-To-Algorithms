import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Link2, Trash2, AlertTriangle } from "lucide-react";
import type { Course, Conflict } from "@shared/schema";
import { CONFLICT_TYPE_LABELS, CONFLICT_TYPE_COLORS } from "@/lib/graph-colors";

interface ConflictsListProps {
  courses: Course[];
  conflicts: Conflict[];
  onDeleteConflict: (conflictId: string) => void;
}

export function ConflictsList({ courses, conflicts, onDeleteConflict }: ConflictsListProps) {
  const getCourse = (courseId: string) => courses.find((c) => c.id === courseId);

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
        <div className="flex items-center gap-2">
          <Link2 className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Conflicts</CardTitle>
        </div>
        <Badge variant="secondary" className="text-xs">
          {conflicts.length} edges
        </Badge>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-[250px]">
          {conflicts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-center px-4">
              <AlertTriangle className="h-8 w-8 text-muted-foreground/50 mb-2" />
              <p className="text-muted-foreground text-sm">No conflicts defined</p>
              <p className="text-muted-foreground/70 text-xs mt-1">
                Add conflicts to model scheduling constraints
              </p>
            </div>
          ) : (
            <div className="space-y-1 p-4 pt-0">
              {conflicts.map((conflict) => {
                const course1 = getCourse(conflict.course1Id);
                const course2 = getCourse(conflict.course2Id);
                const color = CONFLICT_TYPE_COLORS[conflict.type];

                if (!course1 || !course2) return null;

                return (
                  <div
                    key={conflict.id}
                    className="group flex items-center gap-3 p-3 rounded-lg hover-elevate"
                    data-testid={`conflict-item-${conflict.id}`}
                  >
                    <div
                      className="w-1 h-8 rounded-full shrink-0"
                      style={{ backgroundColor: color.stroke }}
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-mono font-semibold">{course1.code}</span>
                        <span className="text-muted-foreground">-</span>
                        <span className="font-mono font-semibold">{course2.code}</span>
                      </div>
                      <Badge
                        variant="outline"
                        className="mt-1 text-xs"
                        style={{ borderColor: color.stroke, color: color.stroke }}
                      >
                        {CONFLICT_TYPE_LABELS[conflict.type]}
                      </Badge>
                    </div>

                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => onDeleteConflict(conflict.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      data-testid={`button-delete-conflict-${conflict.id}`}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
