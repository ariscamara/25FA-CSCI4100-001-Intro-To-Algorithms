import type { Course, Room, ScheduleResult } from "@shared/schema";
import { getTimeSlotLabel } from "@shared/schema";

function escapeCSVField(field: string): string {
  if (field.includes('"') || field.includes(',') || field.includes('\n') || field.includes('\r')) {
    return `"${field.replace(/"/g, '""')}"`;
  }
  return `"${field}"`;
}

export function exportScheduleToCSV(
  scheduleResult: ScheduleResult,
  courses: Course[],
  rooms: Room[]
): void {
  const courseMap = new Map(courses.map((c) => [c.id, c]));
  const roomMap = new Map(rooms.map((r) => [r.id, r]));

  const headers = ["Course Code", "Course Name", "Professor", "Time Slot", "Room", "Color"];
  const rows = scheduleResult.assignments.map((assignment) => {
    const course = courseMap.get(assignment.courseId);
    const room = assignment.roomId ? roomMap.get(assignment.roomId) : null;
    return [
      course?.code || "Unknown",
      course?.name || "Unknown",
      course?.professor || "-",
      getTimeSlotLabel(assignment.timeSlot),
      room?.name || "Unassigned",
      assignment.color,
    ];
  });

  const csvContent = [
    headers.map(escapeCSVField).join(","),
    ...rows.map((row) => row.map(escapeCSVField).join(",")),
  ].join("\n");

  downloadFile(csvContent, "schedule.csv", "text/csv;charset=utf-8");
}

export function exportScheduleToPDF(
  scheduleResult: ScheduleResult,
  courses: Course[],
  rooms: Room[]
): void {
  const courseMap = new Map(courses.map((c) => [c.id, c]));
  const roomMap = new Map(rooms.map((r) => [r.id, r]));

  const groupedByTimeSlot = new Map<number, typeof scheduleResult.assignments>();
  scheduleResult.assignments.forEach((assignment) => {
    if (!groupedByTimeSlot.has(assignment.timeSlot)) {
      groupedByTimeSlot.set(assignment.timeSlot, []);
    }
    groupedByTimeSlot.get(assignment.timeSlot)?.push(assignment);
  });

  let htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Course Schedule Report</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 40px; max-width: 900px; margin: 0 auto; }
        h1 { color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
        .meta { color: #666; margin-bottom: 20px; }
        .stats { background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 30px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
        .stat { text-align: center; }
        .stat-value { font-size: 24px; font-weight: bold; color: #333; }
        .stat-label { font-size: 12px; color: #666; text-transform: uppercase; }
        .timeslot { margin-bottom: 25px; }
        .timeslot-header { background: #333; color: white; padding: 10px 15px; border-radius: 4px 4px 0 0; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 0; }
        th, td { padding: 10px 15px; text-align: left; border: 1px solid #ddd; }
        th { background: #f9f9f9; font-weight: 600; }
        tr:nth-child(even) { background: #fafafa; }
        .color-swatch { width: 20px; height: 20px; border-radius: 4px; display: inline-block; margin-right: 8px; vertical-align: middle; }
        .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px; text-align: center; }
        @media print { body { padding: 20px; } }
      </style>
    </head>
    <body>
      <h1>Course Schedule Report</h1>
      <div class="meta">
        Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
        ${scheduleResult.algorithm ? ` | Algorithm: ${scheduleResult.algorithm.charAt(0).toUpperCase() + scheduleResult.algorithm.slice(1)}` : ""}
      </div>
      
      <div class="stats">
        <div class="stat">
          <div class="stat-value">${courses.length}</div>
          <div class="stat-label">Total Courses</div>
        </div>
        <div class="stat">
          <div class="stat-value">${scheduleResult.totalTimeSlots}</div>
          <div class="stat-label">Time Slots</div>
        </div>
        <div class="stat">
          <div class="stat-value">${scheduleResult.chromaticNumber}</div>
          <div class="stat-label">Chromatic Number</div>
        </div>
      </div>
  `;

  const sortedTimeSlots = Array.from(groupedByTimeSlot.keys()).sort((a, b) => a - b);

  for (const timeSlot of sortedTimeSlots) {
    const assignments = groupedByTimeSlot.get(timeSlot) || [];
    htmlContent += `
      <div class="timeslot">
        <div class="timeslot-header">${getTimeSlotLabel(timeSlot)}</div>
        <table>
          <thead>
            <tr>
              <th>Code</th>
              <th>Course Name</th>
              <th>Professor</th>
              <th>Room</th>
              <th>Color</th>
            </tr>
          </thead>
          <tbody>
    `;

    for (const assignment of assignments) {
      const course = courseMap.get(assignment.courseId);
      const room = assignment.roomId ? roomMap.get(assignment.roomId) : null;
      htmlContent += `
        <tr>
          <td>${course?.code || "Unknown"}</td>
          <td>${course?.name || "Unknown"}</td>
          <td>${course?.professor || "-"}</td>
          <td>${room?.name || "Unassigned"}</td>
          <td><span class="color-swatch" style="background: ${assignment.color};"></span>${assignment.color}</td>
        </tr>
      `;
    }

    htmlContent += `
          </tbody>
        </table>
      </div>
    `;
  }

  if (scheduleResult.validationErrors && scheduleResult.validationErrors.length > 0) {
    htmlContent += `
      <div class="timeslot">
        <div class="timeslot-header" style="background: #dc3545;">Validation Warnings</div>
        <table>
          <tbody>
            ${scheduleResult.validationErrors.map((err) => `<tr><td>${err}</td></tr>`).join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  htmlContent += `
      <div class="footer">
        GraphScheduler - Course Scheduling with Graph Coloring
      </div>
    </body>
    </html>
  `;

  const printWindow = window.open("", "_blank");
  if (printWindow) {
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  } else {
    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "schedule-report.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    alert("Popup was blocked. The schedule report has been downloaded as an HTML file that you can open and print.");
  }
}

function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
