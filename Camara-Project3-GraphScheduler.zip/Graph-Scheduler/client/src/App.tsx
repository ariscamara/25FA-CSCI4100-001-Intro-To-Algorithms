import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Scheduler from "@/pages/scheduler";
import Documentation from "@/pages/documentation";
import ReleaseNotes from "@/pages/release-notes";
import AcademicGuide from "@/pages/academic-guide";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Scheduler} />
      <Route path="/docs" component={Documentation} />
      <Route path="/release-notes" component={ReleaseNotes} />
      <Route path="/academic-guide" component={AcademicGuide} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
