import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  GraduationCap,
  TestTube,
  Target,
  Lightbulb,
  BookOpen,
  Code2,
  CheckCircle2,
  AlertCircle,
  Play,
  BarChart3
} from "lucide-react";

export default function AcademicGuide() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Scheduler
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold" data-testid="text-guide-title">Academic Guide</h1>
          </div>
        </div>
      </header>

      <main className="container py-8 max-w-5xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold tracking-tight mb-2">GraphScheduler Academic Guide</h2>
          <p className="text-muted-foreground text-lg">
            Comprehensive guide covering program purpose, testing procedures, algorithm theory, and academic references
          </p>
        </div>

        <Tabs defaultValue="purpose" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="purpose" data-testid="tab-purpose">Purpose</TabsTrigger>
            <TabsTrigger value="testing" data-testid="tab-testing">Testing</TabsTrigger>
            <TabsTrigger value="problem" data-testid="tab-problem">Problem Solving</TabsTrigger>
            <TabsTrigger value="algorithms" data-testid="tab-algorithms">Algorithms</TabsTrigger>
            <TabsTrigger value="references" data-testid="tab-references">Academic References</TabsTrigger>
          </TabsList>

          <TabsContent value="purpose" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Program Purpose
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <p className="text-base leading-relaxed">
                    <strong>GraphScheduler</strong> is an educational and practical application that demonstrates 
                    the application of graph theory algorithms to solve real-world scheduling problems. 
                    The program specifically addresses the <strong>University Course Timetabling Problem (UCTP)</strong>, 
                    which is a well-known NP-hard combinatorial optimization problem.
                  </p>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="rounded-lg border p-4">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Lightbulb className="h-4 w-4 text-primary" />
                      Educational Objectives
                    </h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Demonstrate graph coloring algorithms in practice
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Visualize algorithm execution and performance
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Compare approximation vs. exact algorithms
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Apply topological sorting for dependency constraints
                      </li>
                    </ul>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Target className="h-4 w-4 text-primary" />
                      Practical Applications
                    </h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        University course scheduling
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Examination timetabling
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Resource allocation optimization
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                        Conflict resolution in scheduling systems
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="rounded-lg bg-muted/50 p-4">
                  <h4 className="font-semibold mb-2">Core Concept: Graph Coloring as Scheduling</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    The program models the scheduling problem as a graph coloring problem where:
                  </p>
                  <div className="grid gap-2 md:grid-cols-3 text-sm">
                    <div className="rounded bg-background p-3 border">
                      <span className="font-medium">Vertices (V)</span>
                      <p className="text-muted-foreground">Courses to be scheduled</p>
                    </div>
                    <div className="rounded bg-background p-3 border">
                      <span className="font-medium">Edges (E)</span>
                      <p className="text-muted-foreground">Conflicts between courses</p>
                    </div>
                    <div className="rounded bg-background p-3 border">
                      <span className="font-medium">Colors (k)</span>
                      <p className="text-muted-foreground">Available time slots</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="testing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TestTube className="h-5 w-5" />
                  How to Test the Program
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Play className="h-4 w-4 text-primary" />
                    Quick Start Testing
                  </h4>
                  <ol className="space-y-3 text-sm">
                    <li className="flex gap-3">
                      <Badge variant="outline" className="shrink-0">1</Badge>
                      <div>
                        <span className="font-medium">Load Example Data</span>
                        <p className="text-muted-foreground">Click the "Load Example" button in the header to populate the system with sample courses, conflicts, and rooms.</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge variant="outline" className="shrink-0">2</Badge>
                      <div>
                        <span className="font-medium">Select an Algorithm</span>
                        <p className="text-muted-foreground">Use the algorithm dropdown to choose between Greedy, Welsh-Powell, DSatur, or Backtracking.</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge variant="outline" className="shrink-0">3</Badge>
                      <div>
                        <span className="font-medium">Generate Schedule</span>
                        <p className="text-muted-foreground">Click "Generate" to run the selected algorithm and create a conflict-free schedule.</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge variant="outline" className="shrink-0">4</Badge>
                      <div>
                        <span className="font-medium">Analyze Results</span>
                        <p className="text-muted-foreground">Review the statistics panel showing chromatic number, execution time, and any validation warnings.</p>
                      </div>
                    </li>
                  </ol>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <BarChart3 className="h-4 w-4 text-primary" />
                    Algorithm Comparison Testing
                  </h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    To compare algorithm performance:
                  </p>
                  <ol className="space-y-2 text-sm text-muted-foreground">
                    <li>1. Load the same dataset</li>
                    <li>2. Run each algorithm and note the chromatic number and execution time</li>
                    <li>3. Compare results - Backtracking should find optimal (minimum) colors but take longer</li>
                    <li>4. DSatur typically performs better than Greedy on sparse graphs</li>
                  </ol>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Test Cases to Verify</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-medium">Conflict-Free Schedule</span>
                        <p className="text-muted-foreground">No two conflicting courses should be assigned the same time slot</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-medium">Prerequisite Ordering</span>
                        <p className="text-muted-foreground">Prerequisite courses should be scheduled in earlier time slots</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-medium">Room Allocation</span>
                        <p className="text-muted-foreground">Each room should only be assigned to one course per time slot</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-orange-500 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-medium">Cycle Detection</span>
                        <p className="text-muted-foreground">Circular prerequisites should be detected and reported as validation errors</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Manual Testing Procedure</h4>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`1. Add Course: CS101 - Intro to Programming (Prof. Smith)
2. Add Course: CS102 - Data Structures (Prof. Smith)
3. Add Conflict: CS101 ↔ CS102 (same_professor)
4. Generate Schedule
5. Verify: CS101 and CS102 have different time slots

6. Add Prerequisite: CS101 → CS102
7. Generate Schedule
8. Verify: CS101 time slot < CS102 time slot

9. Compare execution times across algorithms
10. Export results to CSV/PDF for documentation`}</pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="problem" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5" />
                  How This Program Solves Problems
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <p className="text-base leading-relaxed">
                    The University Course Timetabling Problem involves assigning time slots to courses 
                    while respecting various constraints. This is computationally challenging because 
                    the problem is <strong>NP-complete</strong>, meaning there is no known polynomial-time 
                    algorithm that can solve all instances optimally.
                  </p>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Problem Definition</h4>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs mb-3">
                    <pre>{`Given:
  G = (V, E) where V = courses, E = conflicts
  
Find:
  A coloring c: V → {1, 2, ..., k}
  
Such that:
  ∀(u, v) ∈ E: c(u) ≠ c(v)
  
Minimize:
  k (chromatic number χ(G))`}</pre>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Constraints Handled</h4>
                  <div className="grid gap-3 md:grid-cols-2">
                    {[
                      { type: "Same Professor", desc: "Two courses with the same professor cannot overlap" },
                      { type: "Same Room", desc: "Two courses in the same room cannot overlap" },
                      { type: "Same Students", desc: "Courses with shared students cannot overlap" },
                      { type: "Time Conflict", desc: "Explicit time slot conflicts" },
                      { type: "Prerequisites", desc: "Course A must be scheduled before Course B" },
                    ].map((constraint) => (
                      <div key={constraint.type} className="rounded bg-muted/50 p-3">
                        <span className="font-medium text-sm">{constraint.type}</span>
                        <p className="text-xs text-muted-foreground">{constraint.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Solution Approach</h4>
                  <ol className="space-y-3 text-sm">
                    <li className="flex gap-3">
                      <Badge className="shrink-0">Step 1</Badge>
                      <div>
                        <span className="font-medium">Graph Construction</span>
                        <p className="text-muted-foreground">Build adjacency list representation from courses and conflicts. Time: O(V + E)</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge className="shrink-0">Step 2</Badge>
                      <div>
                        <span className="font-medium">Prerequisite Analysis</span>
                        <p className="text-muted-foreground">Build prerequisite DAG and perform topological sort. Detect cycles. Time: O(V + E)</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge className="shrink-0">Step 3</Badge>
                      <div>
                        <span className="font-medium">Graph Coloring</span>
                        <p className="text-muted-foreground">Apply selected coloring algorithm to assign time slots. Time: varies by algorithm.</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge className="shrink-0">Step 4</Badge>
                      <div>
                        <span className="font-medium">Room Assignment</span>
                        <p className="text-muted-foreground">Greedily assign rooms to courses within each time slot. Time: O(V × R)</p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <Badge className="shrink-0">Step 5</Badge>
                      <div>
                        <span className="font-medium">Validation</span>
                        <p className="text-muted-foreground">Verify prerequisite ordering and report any violations. Time: O(E)</p>
                      </div>
                    </li>
                  </ol>
                </div>

                <div className="rounded-lg border p-4 bg-primary/5">
                  <h4 className="font-semibold mb-2">Why Graph Coloring?</h4>
                  <p className="text-sm text-muted-foreground">
                    Graph coloring provides an elegant abstraction for scheduling problems. Each color 
                    represents a time slot, and the constraint that adjacent vertices cannot share 
                    colors directly maps to the constraint that conflicting courses cannot share time slots. 
                    The chromatic number gives the minimum number of time slots needed.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="algorithms" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code2 className="h-5 w-5" />
                  Algorithms Implemented
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">1. Greedy Coloring Algorithm</h4>
                    <Badge>O(V + E)</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    The basic greedy approach processes vertices in decreasing order of degree and assigns 
                    the smallest available color that doesn't conflict with already-colored neighbors.
                  </p>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs mb-3">
                    <pre>{`GREEDY-COLORING(G):
  Sort vertices by degree (descending)
  for each vertex v in sorted order:
    usedColors ← colors of colored neighbors of v
    c ← smallest color not in usedColors
    color[v] ← c
  return color`}</pre>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    <strong>Guarantee:</strong> Uses at most Δ(G) + 1 colors where Δ(G) is the maximum degree.
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">2. Welsh-Powell Algorithm</h4>
                    <Badge variant="secondary">O(V log V + E)</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    An improvement over basic greedy that processes colors one at a time, assigning 
                    the current color to as many vertices as possible before moving to the next color.
                  </p>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs mb-3">
                    <pre>{`WELSH-POWELL(G):
  Sort vertices by degree (descending)
  color ← 0
  while uncolored vertices exist:
    for each uncolored vertex v in sorted order:
      if no neighbor of v has current color:
        assign color to v
    color ← color + 1
  return coloring`}</pre>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    <strong>Property:</strong> Often produces better results than basic greedy by maximizing color reuse.
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">3. DSatur Algorithm (Degree of Saturation)</h4>
                    <Badge variant="secondary">O(V²)</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    A dynamic ordering heuristic that always colors the vertex with the highest 
                    saturation degree (number of differently colored neighbors), breaking ties by degree.
                  </p>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs mb-3">
                    <pre>{`DSATUR(G):
  Initialize saturation[v] ← 0 for all v
  while uncolored vertices exist:
    v ← vertex with max saturation (ties: max degree)
    c ← smallest color not used by neighbors of v
    color[v] ← c
    for each uncolored neighbor u of v:
      saturation[u] ← saturation[u] + 1
  return coloring`}</pre>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    <strong>Advantage:</strong> Adapts ordering dynamically based on partial coloring, often finding near-optimal solutions.
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">4. Backtracking Algorithm (Exact)</h4>
                    <Badge variant="destructive">O(k^V) worst case</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    An exact algorithm that systematically tries colorings with increasing numbers of 
                    colors until finding a valid k-coloring. Guarantees optimal chromatic number.
                  </p>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs mb-3">
                    <pre>{`BACKTRACKING-COLORING(G):
  for k ← 1 to |V|:
    if SOLVE(0, k):
      return coloring with k colors
      
SOLVE(index, numColors):
  if index = |V|: return true
  v ← vertices[index]
  for c ← 0 to numColors-1:
    if IS-VALID(v, c):
      color[v] ← c
      if SOLVE(index+1, numColors):
        return true
      uncolor v
  return false`}</pre>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    <strong>Optimality:</strong> Finds the chromatic number χ(G), but exponential time for large graphs.
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">5. Topological Sort (for Prerequisites)</h4>
                    <Badge>O(V + E)</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Depth-first search based topological ordering to validate prerequisite constraints 
                    and detect circular dependencies.
                  </p>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`TOPOLOGICAL-SORT(G):
  visited ← ∅, inStack ← ∅, order ← []
  for each vertex v:
    if v ∉ visited:
      DFS(v)
  return reverse(order)
  
DFS(v):
  if v ∈ inStack: CYCLE DETECTED
  if v ∈ visited: return
  visited ← visited ∪ {v}
  inStack ← inStack ∪ {v}
  for each neighbor u of v:
    DFS(u)
  inStack ← inStack - {v}
  order.append(v)`}</pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="references" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Academic References
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border p-4 bg-primary/5">
                  <h4 className="font-semibold mb-2">Primary Textbook Reference</h4>
                  <p className="text-sm mb-2">
                    <strong>Introduction to Algorithms, 4th Edition</strong> (CLRS)<br />
                    Cormen, Leiserson, Rivest, and Stein<br />
                    MIT Press, 2022
                  </p>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Relevant CLRS Chapters</h4>
                  <div className="space-y-4">
                    <div className="rounded bg-muted/50 p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">Chapter 20</Badge>
                        <span className="font-medium text-sm">Elementary Graph Algorithms</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        <strong>Sections 20.1-20.4:</strong> Graph representations (adjacency lists), 
                        BFS, DFS, and topological sorting. Our program implements adjacency list 
                        representation and DFS-based topological sort for prerequisite validation.
                      </p>
                    </div>

                    <div className="rounded bg-muted/50 p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">Chapter 34</Badge>
                        <span className="font-medium text-sm">NP-Completeness</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        <strong>Section 34.5:</strong> Discusses the k-colorability problem as an 
                        NP-complete problem. Our backtracking algorithm implements an exact solution 
                        with exponential worst-case complexity.
                      </p>
                    </div>

                    <div className="rounded bg-muted/50 p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">Chapter 15</Badge>
                        <span className="font-medium text-sm">Greedy Algorithms</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        <strong>Section 15.1-15.3:</strong> Greedy algorithm design paradigm. Our 
                        Greedy and Welsh-Powell algorithms follow this paradigm for approximating 
                        graph coloring.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Algorithm-Specific References</h4>
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="font-medium">Welsh-Powell Algorithm</span>
                      <p className="text-muted-foreground text-xs">
                        Welsh, D.J.A. and Powell, M.B. (1967). "An upper bound for the chromatic number 
                        of a graph and its application to timetabling problems." The Computer Journal, 
                        10(1), 85-86.
                      </p>
                    </div>
                    <div>
                      <span className="font-medium">DSatur Algorithm</span>
                      <p className="text-muted-foreground text-xs">
                        Brélaz, D. (1979). "New methods to color the vertices of a graph." 
                        Communications of the ACM, 22(4), 251-256.
                      </p>
                    </div>
                    <div>
                      <span className="font-medium">Graph Coloring Complexity</span>
                      <p className="text-muted-foreground text-xs">
                        Garey, M.R. and Johnson, D.S. (1979). "Computers and Intractability: A Guide 
                        to the Theory of NP-Completeness." W.H. Freeman.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Theoretical Foundations</h4>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="rounded bg-muted/50 p-3">
                      <span className="font-medium text-sm">Graph Representation</span>
                      <p className="text-xs text-muted-foreground">
                        CLRS 20.1: Adjacency-list representation for sparse graphs. Space: O(V + E)
                      </p>
                    </div>
                    <div className="rounded bg-muted/50 p-3">
                      <span className="font-medium text-sm">DFS & Topological Sort</span>
                      <p className="text-xs text-muted-foreground">
                        CLRS 20.3-20.4: Depth-first search forest and DAG topological ordering. Time: O(V + E)
                      </p>
                    </div>
                    <div className="rounded bg-muted/50 p-3">
                      <span className="font-medium text-sm">Greedy Choice Property</span>
                      <p className="text-xs text-muted-foreground">
                        CLRS 15.1: Local optimal choices leading to global approximation
                      </p>
                    </div>
                    <div className="rounded bg-muted/50 p-3">
                      <span className="font-medium text-sm">Backtracking</span>
                      <p className="text-xs text-muted-foreground">
                        CLRS 34.5: Exhaustive search with pruning for NP-complete problems
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Complexity Analysis Summary</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="py-2 text-left font-medium">Component</th>
                          <th className="py-2 text-left font-medium">Time</th>
                          <th className="py-2 text-left font-medium">Space</th>
                          <th className="py-2 text-left font-medium">CLRS Reference</th>
                        </tr>
                      </thead>
                      <tbody className="text-muted-foreground">
                        <tr className="border-b">
                          <td className="py-2">Adjacency List</td>
                          <td className="py-2">O(V + E)</td>
                          <td className="py-2">O(V + E)</td>
                          <td className="py-2">Section 20.1</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">Topological Sort</td>
                          <td className="py-2">O(V + E)</td>
                          <td className="py-2">O(V)</td>
                          <td className="py-2">Section 20.4</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">Greedy Coloring</td>
                          <td className="py-2">O(V + E)</td>
                          <td className="py-2">O(V)</td>
                          <td className="py-2">Chapter 15</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">DSatur</td>
                          <td className="py-2">O(V²)</td>
                          <td className="py-2">O(V)</td>
                          <td className="py-2">-</td>
                        </tr>
                        <tr>
                          <td className="py-2">Backtracking</td>
                          <td className="py-2">O(k^V)</td>
                          <td className="py-2">O(V)</td>
                          <td className="py-2">Section 34.5</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="rounded-lg border p-4 bg-muted/30">
                  <h4 className="font-semibold mb-2">Academic Compliance Statement</h4>
                  <p className="text-sm text-muted-foreground">
                    This program implements algorithms as described in standard algorithm textbooks, 
                    particularly "Introduction to Algorithms" (CLRS). The graph coloring problem and 
                    its NP-completeness are well-established in computational complexity theory. 
                    The approximation algorithms (Greedy, Welsh-Powell, DSatur) provide polynomial-time 
                    heuristics, while the backtracking algorithm demonstrates exact solution techniques 
                    for NP-complete problems.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
