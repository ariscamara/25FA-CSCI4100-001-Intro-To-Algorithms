import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2, Edit2, User, BookOpen } from "lucide-react";
import type { Course, Conflict, ScheduleAssignment } from "@shared/schema";
import { getColorForTimeSlot } from "@/lib/graph-colors";

interface CourseListProps {
  courses: Course[];
  conflicts: Conflict[];
  assignments: ScheduleAssignment[];
  selectedCourseId: string | null;
  onSelectCourse: (course: Course | null) => void;
  onEditCourse: (course: Course) => void;
  onDeleteCourse: (courseId: string) => void;
}

export function CourseList({
  courses,
  conflicts,
  assignments,
  selectedCourseId,
  onSelectCourse,
  onEditCourse,
  onDeleteCourse,
}: CourseListProps) {
  const getConflictCount = (courseId: string) => {
    return conflicts.filter(
      (c) => c.course1Id === courseId || c.course2Id === courseId
    ).length;
  };

  const getAssignment = (courseId: string) => {
    return assignments.find((a) => a.courseId === courseId);
  };

  return (
    <Card className="flex flex-col h-full">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Courses</CardTitle>
        </div>
        <Badge variant="secondary" className="text-xs">
          {courses.length} total
        </Badge>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-[400px]">
          {courses.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-center px-4">
              <BookOpen className="h-8 w-8 text-muted-foreground/50 mb-2" />
              <p className="text-muted-foreground text-sm">No courses added yet</p>
            </div>
          ) : (
            <div className="space-y-1 p-4 pt-0">
              {courses.map((course) => {
                const conflictCount = getConflictCount(course.id);
                const assignment = getAssignment(course.id);
                const color = assignment ? getColorForTimeSlot(assignment.timeSlot) : null;
                const isSelected = selectedCourseId === course.id;

                return (
                  <div
                    key={course.id}
                    onClick={() => onSelectCourse(isSelected ? null : course)}
                    className={`
                      group flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors
                      ${isSelected ? "bg-primary/10 border border-primary/20" : "hover-elevate"}
                    `}
                    data-testid={`course-item-${course.id}`}
                  >
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                      style={{
                        backgroundColor: color?.bg || "hsl(210, 10%, 85%)",
                        color: color?.text || "#333",
                      }}
                    >
                      {assignment ? `T${assignment.timeSlot}` : course.code.slice(0, 2)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold text-sm">
                          {course.code}
                        </span>
                        {conflictCount > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {conflictCount} conflict{conflictCount !== 1 ? "s" : ""}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {course.name}
                      </p>
                      {course.professor && (
                        <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                          <User className="h-3 w-3" />
                          {course.professor}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditCourse(course);
                        }}
                        data-testid={`button-edit-${course.id}`}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteCourse(course.id);
                        }}
                        data-testid={`button-delete-${course.id}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
