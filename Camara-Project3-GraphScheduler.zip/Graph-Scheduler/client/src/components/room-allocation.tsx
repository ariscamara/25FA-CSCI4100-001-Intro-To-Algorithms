import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Building, Clock } from "lucide-react";
import type { Course, Room, ScheduleAssignment, ScheduleResult } from "@shared/schema";
import { getColorForTimeSlot } from "@/lib/graph-colors";

interface RoomAllocationProps {
  courses: Course[];
  rooms: Room[];
  scheduleResult: ScheduleResult | null;
}

export function RoomAllocation({ courses, rooms, scheduleResult }: RoomAllocationProps) {
  if (!scheduleResult || scheduleResult.assignments.length === 0) {
    return (
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center gap-2 pb-4">
          <Building className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Room Allocation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center h-32 text-center">
            <Building className="h-10 w-10 text-muted-foreground/50 mb-3" />
            <p className="text-muted-foreground">Generate a schedule to see room allocation</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getCourse = (courseId: string) => courses.find((c) => c.id === courseId);

  const timeSlots = Array.from(
    { length: scheduleResult.totalTimeSlots },
    (_, i) => i
  );

  const assignmentsByTimeSlot = new Map<number, ScheduleAssignment[]>();
  scheduleResult.assignments.forEach((a) => {
    const existing = assignmentsByTimeSlot.get(a.timeSlot) || [];
    existing.push(a);
    assignmentsByTimeSlot.set(a.timeSlot, existing);
  });

  const usedRooms = new Set<string>();
  scheduleResult.assignments.forEach((a) => {
    if (a.roomId) usedRooms.add(a.roomId);
  });

  const displayRooms = rooms.filter((r) => usedRooms.has(r.id));
  if (displayRooms.length === 0 && rooms.length > 0) {
    displayRooms.push(...rooms.slice(0, 4));
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
        <div className="flex items-center gap-2">
          <Building className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Room Allocation Matrix</CardTitle>
        </div>
        <Badge variant="secondary" className="text-xs">
          {displayRooms.length} rooms
        </Badge>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-[300px]">
          <div className="p-4 pt-0">
            <div className="grid gap-2" style={{ gridTemplateColumns: `80px repeat(${displayRooms.length || 1}, 1fr)` }}>
              <div className="h-10 flex items-center justify-center">
                <Clock className="h-4 w-4 text-muted-foreground" />
              </div>
              {displayRooms.map((room) => (
                <div
                  key={room.id}
                  className="h-10 flex items-center justify-center font-mono text-sm font-medium bg-muted rounded-md"
                >
                  {room.name}
                </div>
              ))}

              {timeSlots.map((slot) => {
                const color = getColorForTimeSlot(slot);
                const assignments = assignmentsByTimeSlot.get(slot) || [];

                return (
                  <>
                    <div
                      key={`slot-${slot}`}
                      className="h-14 flex items-center justify-center font-mono text-sm font-semibold rounded-md"
                      style={{ backgroundColor: color.bg, color: color.text }}
                    >
                      T{slot}
                    </div>
                    {displayRooms.map((room) => {
                      const assignment = assignments.find((a) => a.roomId === room.id);
                      const course = assignment ? getCourse(assignment.courseId) : null;

                      return (
                        <div
                          key={`${slot}-${room.id}`}
                          className={`
                            h-14 flex items-center justify-center rounded-md text-sm
                            ${course ? "bg-card border border-card-border" : "bg-muted/30"}
                          `}
                        >
                          {course ? (
                            <span className="font-mono font-medium">{course.code}</span>
                          ) : (
                            <span className="text-muted-foreground/50">-</span>
                          )}
                        </div>
                      );
                    })}
                  </>
                );
              })}
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
