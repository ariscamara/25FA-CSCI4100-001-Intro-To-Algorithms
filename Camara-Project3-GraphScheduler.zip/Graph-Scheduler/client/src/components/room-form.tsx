import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Plus, Building } from "lucide-react";
import { insertRoomSchema, type InsertRoom } from "@shared/schema";

interface RoomFormProps {
  onSubmit: (data: InsertRoom) => void;
  isPending?: boolean;
}

export function RoomForm({ onSubmit, isPending }: RoomFormProps) {
  const form = useForm<InsertRoom>({
    resolver: zodResolver(insertRoomSchema),
    defaultValues: {
      name: "",
      capacity: 30,
    },
  });

  const handleSubmit = (data: InsertRoom) => {
    onSubmit(data);
    form.reset();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-2 pb-4">
        <Building className="h-5 w-5 text-muted-foreground" />
        <CardTitle className="text-lg">Add Room</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Room Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Room 101"
                        {...field}
                        data-testid="input-room-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="capacity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Capacity</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={1}
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                        data-testid="input-room-capacity"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={isPending} data-testid="button-add-room">
                <Plus className="h-4 w-4 mr-2" />
                Add Room
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
