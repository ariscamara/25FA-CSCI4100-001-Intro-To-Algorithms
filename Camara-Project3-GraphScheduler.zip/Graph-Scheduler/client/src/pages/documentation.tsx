import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  BookOpen, 
  Code2, 
  Database, 
  Layers, 
  Network, 
  Palette,
  Server,
  Cpu,
  GitBranch
} from "lucide-react";

export default function Documentation() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Scheduler
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold" data-testid="text-doc-title">Technical Documentation</h1>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold tracking-tight mb-2">GraphScheduler Documentation</h2>
          <p className="text-muted-foreground text-lg">
            Comprehensive technical guide for the Graph Coloring Course Scheduling System
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="algorithms" data-testid="tab-algorithms">Algorithms</TabsTrigger>
            <TabsTrigger value="architecture" data-testid="tab-architecture">Architecture</TabsTrigger>
            <TabsTrigger value="api" data-testid="tab-api">API Reference</TabsTrigger>
            <TabsTrigger value="data" data-testid="tab-data">Data Models</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                  System Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  GraphScheduler is a university course scheduling application that leverages graph coloring 
                  algorithms to solve complex scheduling and resource allocation problems. The system models 
                  courses as graph nodes and conflicts as edges, then applies various coloring algorithms to 
                  assign optimal time slots and rooms without conflicts.
                </p>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <div className="rounded-lg border p-4">
                    <h4 className="font-semibold mb-2">Core Problem</h4>
                    <p className="text-sm text-muted-foreground">
                      Assign minimum colors (time slots) to course nodes such that no two adjacent nodes 
                      (conflicting courses) share the same color.
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h4 className="font-semibold mb-2">Conflict Types</h4>
                    <p className="text-sm text-muted-foreground">
                      Same professor, same room, shared students, overlapping times, and prerequisite dependencies.
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h4 className="font-semibold mb-2">Output</h4>
                    <p className="text-sm text-muted-foreground">
                      Conflict-free schedule with time slot assignments, room allocations, and validation reports.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="grid gap-3 md:grid-cols-2">
                  {[
                    "Multiple graph coloring algorithms (Greedy, Welsh-Powell, DSatur, Backtracking)",
                    "Real-time conflict visualization with interactive graph",
                    "Prerequisite constraint validation with topological ordering",
                    "Dynamic room allocation based on capacity",
                    "Performance metrics and algorithm comparison",
                    "CSV and PDF export functionality",
                    "Semester/term management",
                    "Dark/light theme support"
                  ].map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5 shrink-0">
                        {i + 1}
                      </Badge>
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="algorithms" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  Graph Coloring Algorithms
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">Greedy Algorithm</h4>
                      <Badge>O(V + E)</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Simple first-fit approach that processes vertices in arbitrary order and assigns 
                      the smallest available color not used by neighbors.
                    </p>
                    <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                      <pre>{`for each vertex v in G:
  available = {1, 2, ..., k}
  for each neighbor u of v:
    remove color[u] from available
  color[v] = min(available)`}</pre>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">Welsh-Powell Algorithm</h4>
                      <Badge>O(V log V + E)</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Improved greedy that sorts vertices by degree (descending) before coloring. 
                      Higher-degree vertices get colored first, often resulting in fewer colors.
                    </p>
                    <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                      <pre>{`vertices = sort by degree (descending)
for each vertex v in vertices:
  assign smallest color not used by neighbors`}</pre>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">DSatur Algorithm</h4>
                      <Badge variant="secondary">O(V^2)</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Dynamic saturation degree ordering. Always colors the vertex with the highest 
                      saturation degree (number of differently colored neighbors) next. More adaptive 
                      than Welsh-Powell.
                    </p>
                    <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                      <pre>{`while uncolored vertices exist:
  v = vertex with max saturation degree
  (break ties by max degree)
  color[v] = smallest available color
  update saturation of v's neighbors`}</pre>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">Backtracking Algorithm</h4>
                      <Badge variant="destructive">O(k^V)</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Exhaustive search that finds the optimal (minimum) chromatic number. Tries each 
                      color assignment and backtracks on conflicts. Guaranteed optimal but exponential 
                      time complexity.
                    </p>
                    <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                      <pre>{`for k = 1 to V:
  if canColor(graph, k):
    return k  // chromatic number found
    
canColor(graph, k):
  return backtrack(0, k)  // try all combinations`}</pre>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Algorithm Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 text-left font-medium">Algorithm</th>
                        <th className="py-2 text-left font-medium">Time Complexity</th>
                        <th className="py-2 text-left font-medium">Optimality</th>
                        <th className="py-2 text-left font-medium">Best For</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-2">Greedy</td>
                        <td className="py-2">O(V + E)</td>
                        <td className="py-2">Approximation</td>
                        <td className="py-2">Large graphs, quick results</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">Welsh-Powell</td>
                        <td className="py-2">O(V log V + E)</td>
                        <td className="py-2">Better approximation</td>
                        <td className="py-2">Balanced performance</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">DSatur</td>
                        <td className="py-2">O(V^2)</td>
                        <td className="py-2">Good approximation</td>
                        <td className="py-2">Sparse graphs, quality focus</td>
                      </tr>
                      <tr>
                        <td className="py-2">Backtracking</td>
                        <td className="py-2">O(k^V)</td>
                        <td className="py-2">Optimal</td>
                        <td className="py-2">Small graphs, exact solution</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="architecture" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  System Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Palette className="h-4 w-4 text-primary" />
                      <h4 className="font-semibold">Frontend</h4>
                    </div>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>React 18 with TypeScript</li>
                      <li>Wouter for client-side routing</li>
                      <li>TanStack React Query for server state</li>
                      <li>Tailwind CSS with Shadcn/ui components</li>
                      <li>Vite for development and bundling</li>
                    </ul>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Server className="h-4 w-4 text-primary" />
                      <h4 className="font-semibold">Backend</h4>
                    </div>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>Express.js with TypeScript</li>
                      <li>RESTful JSON API under /api/*</li>
                      <li>In-memory storage (IStorage interface)</li>
                      <li>Zod schema validation</li>
                      <li>Drizzle ORM ready for PostgreSQL</li>
                    </ul>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <GitBranch className="h-4 w-4 text-primary" />
                    <h4 className="font-semibold">Project Structure</h4>
                  </div>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`├── client/
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utilities (queryClient, exports)
│   │   └── pages/          # Route pages
├── server/
│   ├── routes.ts           # API endpoint definitions
│   ├── storage.ts          # Data persistence layer
│   ├── graph-coloring.ts   # Core algorithms
│   └── color-utils.ts      # Time slot utilities
└── shared/
    └── schema.ts           # Shared types and Zod schemas`}</pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code2 className="h-5 w-5" />
                  API Reference
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  {
                    group: "Courses",
                    endpoints: [
                      { method: "GET", path: "/api/courses", desc: "List all courses" },
                      { method: "POST", path: "/api/courses", desc: "Create a new course" },
                      { method: "GET", path: "/api/courses/:id", desc: "Get course by ID" },
                      { method: "PATCH", path: "/api/courses/:id", desc: "Update course" },
                      { method: "DELETE", path: "/api/courses/:id", desc: "Delete course" },
                    ]
                  },
                  {
                    group: "Conflicts",
                    endpoints: [
                      { method: "GET", path: "/api/conflicts", desc: "List all conflicts" },
                      { method: "POST", path: "/api/conflicts", desc: "Create a conflict" },
                      { method: "DELETE", path: "/api/conflicts/:id", desc: "Delete conflict" },
                    ]
                  },
                  {
                    group: "Rooms",
                    endpoints: [
                      { method: "GET", path: "/api/rooms", desc: "List all rooms" },
                      { method: "POST", path: "/api/rooms", desc: "Create a room" },
                      { method: "DELETE", path: "/api/rooms/:id", desc: "Delete room" },
                    ]
                  },
                  {
                    group: "Schedule",
                    endpoints: [
                      { method: "POST", path: "/api/schedule/generate", desc: "Generate schedule using selected algorithm" },
                      { method: "GET", path: "/api/schedule", desc: "Get current schedule" },
                      { method: "DELETE", path: "/api/schedule/reset", desc: "Reset all data" },
                    ]
                  },
                  {
                    group: "Semesters",
                    endpoints: [
                      { method: "GET", path: "/api/semesters", desc: "List all semesters" },
                      { method: "POST", path: "/api/semesters", desc: "Create semester" },
                      { method: "PUT", path: "/api/semesters/:id/activate", desc: "Set active semester" },
                      { method: "DELETE", path: "/api/semesters/:id", desc: "Delete semester" },
                    ]
                  }
                ].map((group) => (
                  <div key={group.group} className="rounded-lg border p-4">
                    <h4 className="font-semibold mb-3">{group.group}</h4>
                    <div className="space-y-2">
                      {group.endpoints.map((ep, i) => (
                        <div key={i} className="flex items-center gap-3 text-sm">
                          <Badge 
                            variant={ep.method === "GET" ? "outline" : ep.method === "POST" ? "default" : ep.method === "DELETE" ? "destructive" : "secondary"}
                            className="w-16 justify-center font-mono text-xs"
                          >
                            {ep.method}
                          </Badge>
                          <code className="text-muted-foreground">{ep.path}</code>
                          <span className="text-muted-foreground/70">- {ep.desc}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="data" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  Data Models
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Course</h4>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`{
  id: string;          // UUID
  code: string;        // e.g., "CS101"
  name: string;        // e.g., "Intro to Programming"
  professor: string;   // Professor name
  students: string[];  // List of student IDs
  preferredRoom?: string;  // Optional room preference
  prerequisites?: string[]; // Course IDs that must be scheduled first
}`}</pre>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Conflict</h4>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`{
  id: string;
  course1Id: string;
  course2Id: string;
  type: "same_professor" | "same_room" | "same_students" | 
        "same_timeslot" | "prerequisite";
}`}</pre>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">ScheduleResult</h4>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`{
  assignments: Array<{
    courseId: string;
    timeSlot: number;   // 0-indexed slot number
    roomId?: string;
    color: string;      // Hex color for visualization
  }>;
  chromaticNumber: number;  // Minimum colors used
  algorithm: string;        // Algorithm used
  executionTimeMs: number;  // Performance metric
  validationErrors?: string[];
}`}</pre>
                  </div>
                </div>

                <div className="rounded-lg border p-4">
                  <h4 className="font-semibold mb-3">Semester</h4>
                  <div className="bg-muted/50 rounded p-3 font-mono text-xs">
                    <pre>{`{
  id: string;
  name: string;        // e.g., "Fall 2024"
  startDate?: string;  // ISO date
  endDate?: string;    // ISO date
  isActive: boolean;   // Currently selected semester
}`}</pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
