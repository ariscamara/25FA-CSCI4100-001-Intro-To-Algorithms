import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link2, Plus } from "lucide-react";
import { type Course, type InsertConflict, conflictTypes } from "@shared/schema";
import { CONFLICT_TYPE_LABELS } from "@/lib/graph-colors";

interface ConflictFormProps {
  courses: Course[];
  onSubmit: (data: InsertConflict) => void;
  isPending?: boolean;
}

export function ConflictForm({ courses, onSubmit, isPending }: ConflictFormProps) {
  const [course1Id, setCourse1Id] = useState<string>("");
  const [course2Id, setCourse2Id] = useState<string>("");
  const [type, setType] = useState<string>("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!course1Id || !course2Id || !type || course1Id === course2Id) return;

    onSubmit({
      course1Id,
      course2Id,
      type: type as typeof conflictTypes[number],
    });

    setCourse1Id("");
    setCourse2Id("");
    setType("");
  };

  const isValid = course1Id && course2Id && type && course1Id !== course2Id;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-2 pb-4">
        <Link2 className="h-5 w-5 text-muted-foreground" />
        <CardTitle className="text-lg">Add Conflict</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="course1">Course 1</Label>
              <Select value={course1Id} onValueChange={setCourse1Id}>
                <SelectTrigger id="course1" data-testid="select-course1">
                  <SelectValue placeholder="Select course" />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((course) => (
                    <SelectItem key={course.id} value={course.id}>
                      {course.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="course2">Course 2</Label>
              <Select value={course2Id} onValueChange={setCourse2Id}>
                <SelectTrigger id="course2" data-testid="select-course2">
                  <SelectValue placeholder="Select course" />
                </SelectTrigger>
                <SelectContent>
                  {courses
                    .filter((c) => c.id !== course1Id)
                    .map((course) => (
                      <SelectItem key={course.id} value={course.id}>
                        {course.code}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="conflictType">Conflict Type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger id="conflictType" data-testid="select-conflict-type">
                <SelectValue placeholder="Select conflict type" />
              </SelectTrigger>
              <SelectContent>
                {conflictTypes.map((conflictType) => (
                  <SelectItem key={conflictType} value={conflictType}>
                    {CONFLICT_TYPE_LABELS[conflictType]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end pt-2">
            <Button type="submit" disabled={!isValid || isPending} data-testid="button-add-conflict">
              <Plus className="h-4 w-4 mr-2" />
              Add Conflict
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
