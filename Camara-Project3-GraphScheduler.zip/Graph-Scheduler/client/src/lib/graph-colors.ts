export const TIME_SLOT_COLORS = [
  { bg: "hsl(217, 91%, 48%)", text: "#ffffff", name: "Blue" },
  { bg: "hsl(142, 76%, 36%)", text: "#ffffff", name: "Green" },
  { bg: "hsl(262, 83%, 58%)", text: "#ffffff", name: "Purple" },
  { bg: "hsl(32, 95%, 44%)", text: "#ffffff", name: "Orange" },
  { bg: "hsl(340, 82%, 52%)", text: "#ffffff", name: "Pink" },
  { bg: "hsl(180, 70%, 35%)", text: "#ffffff", name: "Teal" },
  { bg: "hsl(45, 93%, 47%)", text: "#1a1a1a", name: "Yellow" },
  { bg: "hsl(0, 84%, 42%)", text: "#ffffff", name: "Red" },
  { bg: "hsl(280, 65%, 45%)", text: "#ffffff", name: "Violet" },
  { bg: "hsl(200, 80%, 40%)", text: "#ffffff", name: "Cyan" },
];

export function getColorForTimeSlot(timeSlot: number): { bg: string; text: string; name: string } {
  return TIME_SLOT_COLORS[timeSlot % TIME_SLOT_COLORS.length];
}

export const CONFLICT_TYPE_COLORS = {
  same_professor: { stroke: "#ef4444", dash: "0" },
  same_room: { stroke: "#f59e0b", dash: "5,5" },
  same_students: { stroke: "#10b981", dash: "10,5" },
  same_timeslot: { stroke: "#8b5cf6", dash: "2,2" },
  prerequisite: { stroke: "#6366f1", dash: "15,5,5,5" },
};

export const CONFLICT_TYPE_LABELS: Record<string, string> = {
  same_professor: "Same Professor",
  same_room: "Same Room",
  same_students: "Same Students",
  same_timeslot: "Same Time Slot",
  prerequisite: "Prerequisite",
};
