import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCourseSchema, insertConflictSchema, insertRoomSchema, insertSemesterSchema } from "@shared/schema";
import { generateSchedule, addCourseToSchedule } from "./graph-coloring";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/courses", async (_req, res) => {
    const courses = await storage.getCourses();
    res.json(courses);
  });

  app.get("/api/courses/:id", async (req, res) => {
    const course = await storage.getCourse(req.params.id);
    if (!course) {
      return res.status(404).json({ error: "Course not found" });
    }
    res.json(course);
  });

  app.post("/api/courses", async (req, res) => {
    const result = insertCourseSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }
    const course = await storage.createCourse(result.data);
    res.status(201).json(course);
  });

  app.patch("/api/courses/:id", async (req, res) => {
    const result = insertCourseSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }
    const course = await storage.updateCourse(req.params.id, result.data);
    if (!course) {
      return res.status(404).json({ error: "Course not found" });
    }
    res.json(course);
  });

  app.delete("/api/courses/:id", async (req, res) => {
    await storage.deleteConflictsByCourse(req.params.id);
    const deleted = await storage.deleteCourse(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Course not found" });
    }
    res.status(204).send();
  });

  app.get("/api/conflicts", async (_req, res) => {
    const conflicts = await storage.getConflicts();
    res.json(conflicts);
  });

  app.post("/api/conflicts", async (req, res) => {
    const result = insertConflictSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }

    const course1 = await storage.getCourse(result.data.course1Id);
    const course2 = await storage.getCourse(result.data.course2Id);
    if (!course1 || !course2) {
      return res.status(400).json({ error: "One or both courses not found" });
    }

    const conflict = await storage.createConflict(result.data);
    res.status(201).json(conflict);
  });

  app.delete("/api/conflicts/:id", async (req, res) => {
    const deleted = await storage.deleteConflict(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Conflict not found" });
    }
    res.status(204).send();
  });

  app.get("/api/rooms", async (_req, res) => {
    const rooms = await storage.getRooms();
    res.json(rooms);
  });

  app.post("/api/rooms", async (req, res) => {
    const result = insertRoomSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }
    const room = await storage.createRoom(result.data);
    res.status(201).json(room);
  });

  app.delete("/api/rooms/:id", async (req, res) => {
    const deleted = await storage.deleteRoom(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.status(204).send();
  });

  app.get("/api/schedule", async (_req, res) => {
    const schedule = await storage.getScheduleResult();
    res.json(schedule);
  });

  app.post("/api/schedule/generate", async (req, res) => {
    const algorithm = req.body?.algorithm || "greedy";
    const courses = await storage.getCourses();
    const conflicts = await storage.getConflicts();
    const rooms = await storage.getRooms();

    const result = generateSchedule(courses, conflicts, rooms, algorithm);
    await storage.setScheduleResult(result);

    res.json(result);
  });

  app.post("/api/schedule/reset", async (_req, res) => {
    await storage.setScheduleResult(null);
    res.status(204).send();
  });

  app.post("/api/schedule/add-course", async (req, res) => {
    const { courseId } = req.body;
    if (!courseId) {
      return res.status(400).json({ error: "courseId is required" });
    }

    const course = await storage.getCourse(courseId);
    if (!course) {
      return res.status(404).json({ error: "Course not found" });
    }

    const existingResult = await storage.getScheduleResult();
    if (!existingResult) {
      return res.status(400).json({ error: "No existing schedule to add to" });
    }

    const conflicts = await storage.getConflicts();
    const rooms = await storage.getRooms();
    const allCourses = await storage.getCourses();

    const result = addCourseToSchedule(existingResult, course, conflicts, rooms, allCourses);
    await storage.setScheduleResult(result);

    res.json(result);
  });

  app.get("/api/semesters", async (_req, res) => {
    const semesters = await storage.getSemesters();
    res.json(semesters);
  });

  app.get("/api/semesters/:id", async (req, res) => {
    const semester = await storage.getSemester(req.params.id);
    if (!semester) {
      return res.status(404).json({ error: "Semester not found" });
    }
    res.json(semester);
  });

  app.post("/api/semesters", async (req, res) => {
    const result = insertSemesterSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }
    const semester = await storage.createSemester(result.data);
    res.status(201).json(semester);
  });

  app.patch("/api/semesters/:id", async (req, res) => {
    const result = insertSemesterSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error.issues });
    }
    const semester = await storage.updateSemester(req.params.id, result.data);
    if (!semester) {
      return res.status(404).json({ error: "Semester not found" });
    }
    res.json(semester);
  });

  app.delete("/api/semesters/:id", async (req, res) => {
    const deleted = await storage.deleteSemester(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Semester not found" });
    }
    res.status(204).send();
  });

  app.post("/api/semesters/:id/activate", async (req, res) => {
    const semester = await storage.setActiveSemester(req.params.id);
    if (!semester) {
      return res.status(404).json({ error: "Semester not found" });
    }
    res.json(semester);
  });

  app.post("/api/example", async (_req, res) => {
    await storage.clearAll();

    const c1 = await storage.createCourse({ code: "C1", name: "Introduction to Programming", professor: "Dr. Smith", students: [] });
    const c2 = await storage.createCourse({ code: "C2", name: "Data Structures", professor: "Dr. Smith", students: [] });
    const c3 = await storage.createCourse({ code: "C3", name: "Database Systems", professor: "Dr. Johnson", students: [] });
    const c4 = await storage.createCourse({ code: "C4", name: "Operating Systems", professor: "Dr. Williams", students: [] });
    const c5 = await storage.createCourse({ code: "C5", name: "Computer Networks", professor: "Dr. Johnson", students: [] });
    const c6 = await storage.createCourse({ code: "C6", name: "Software Engineering", professor: "Dr. Williams", students: [] });

    await storage.createConflict({ course1Id: c1.id, course2Id: c2.id, type: "same_professor" });
    await storage.createConflict({ course1Id: c1.id, course2Id: c3.id, type: "same_room" });
    await storage.createConflict({ course1Id: c2.id, course2Id: c4.id, type: "same_timeslot" });
    await storage.createConflict({ course1Id: c3.id, course2Id: c5.id, type: "same_students" });
    await storage.createConflict({ course1Id: c4.id, course2Id: c6.id, type: "same_timeslot" });
    await storage.createConflict({ course1Id: c5.id, course2Id: c6.id, type: "same_professor" });

    await storage.createRoom({ name: "Room 101", capacity: 40 });
    await storage.createRoom({ name: "Room 102", capacity: 35 });
    await storage.createRoom({ name: "Room 103", capacity: 50 });
    await storage.createRoom({ name: "Room 104", capacity: 30 });

    res.status(201).json({ message: "Example data loaded" });
  });

  return httpServer;
}
