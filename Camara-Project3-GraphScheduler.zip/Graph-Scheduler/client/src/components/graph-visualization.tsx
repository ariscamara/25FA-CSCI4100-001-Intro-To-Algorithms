import { useRef, useEffect, useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ZoomIn, ZoomOut, Maximize2, Move } from "lucide-react";
import type { Course, Conflict, ScheduleAssignment } from "@shared/schema";
import { getColorForTimeSlot, CONFLICT_TYPE_COLORS, CONFLICT_TYPE_LABELS } from "@/lib/graph-colors";

interface GraphVisualizationProps {
  courses: Course[];
  conflicts: Conflict[];
  assignments: ScheduleAssignment[];
  onSelectCourse: (course: Course | null) => void;
  selectedCourseId: string | null;
}

interface NodePosition {
  x: number;
  y: number;
  vx: number;
  vy: number;
}

export function GraphVisualization({
  courses,
  conflicts,
  assignments,
  onSelectCourse,
  selectedCourseId,
}: GraphVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [positions, setPositions] = useState<Map<string, NodePosition>>(new Map());
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredCourse, setHoveredCourse] = useState<string | null>(null);
  const [draggingNode, setDraggingNode] = useState<string | null>(null);
  const animationRef = useRef<number>();

  const NODE_RADIUS = 32;

  const initializePositions = useCallback(() => {
    if (!containerRef.current) return;
    const { width, height } = containerRef.current.getBoundingClientRect();
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.35;

    const newPositions = new Map<string, NodePosition>();
    courses.forEach((course, index) => {
      const angle = (2 * Math.PI * index) / courses.length - Math.PI / 2;
      newPositions.set(course.id, {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
        vx: 0,
        vy: 0,
      });
    });
    setPositions(newPositions);
  }, [courses]);

  useEffect(() => {
    initializePositions();
  }, [initializePositions]);

  const applyForceSimulation = useCallback(() => {
    if (positions.size === 0 || !containerRef.current) return;
    
    const { width, height } = containerRef.current.getBoundingClientRect();
    const newPositions = new Map(positions);
    const damping = 0.85;
    const repulsion = 8000;
    const attraction = 0.008;
    const centerForce = 0.01;

    courses.forEach((course) => {
      const pos = newPositions.get(course.id);
      if (!pos || course.id === draggingNode) return;

      let fx = 0, fy = 0;

      courses.forEach((other) => {
        if (course.id === other.id) return;
        const otherPos = newPositions.get(other.id);
        if (!otherPos) return;

        const dx = pos.x - otherPos.x;
        const dy = pos.y - otherPos.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = repulsion / (dist * dist);
        fx += (dx / dist) * force;
        fy += (dy / dist) * force;
      });

      conflicts.forEach((conflict) => {
        let otherId: string | null = null;
        if (conflict.course1Id === course.id) otherId = conflict.course2Id;
        if (conflict.course2Id === course.id) otherId = conflict.course1Id;
        if (!otherId) return;

        const otherPos = newPositions.get(otherId);
        if (!otherPos) return;

        const dx = otherPos.x - pos.x;
        const dy = otherPos.y - pos.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const idealDist = 150;
        const force = (dist - idealDist) * attraction;
        fx += (dx / dist) * force;
        fy += (dy / dist) * force;
      });

      const centerX = width / 2;
      const centerY = height / 2;
      fx += (centerX - pos.x) * centerForce;
      fy += (centerY - pos.y) * centerForce;

      pos.vx = (pos.vx + fx) * damping;
      pos.vy = (pos.vy + fy) * damping;
      pos.x += pos.vx;
      pos.y += pos.vy;

      const padding = NODE_RADIUS + 10;
      pos.x = Math.max(padding, Math.min(width - padding, pos.x));
      pos.y = Math.max(padding, Math.min(height - padding, pos.y));
    });

    setPositions(newPositions);
  }, [positions, courses, conflicts, draggingNode]);

  useEffect(() => {
    const simulate = () => {
      applyForceSimulation();
      animationRef.current = requestAnimationFrame(simulate);
    };
    animationRef.current = requestAnimationFrame(simulate);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [applyForceSimulation]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx || !containerRef.current) return;

    const { width, height } = containerRef.current.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(offset.x, offset.y);
    ctx.scale(zoom, zoom);

    conflicts.forEach((conflict) => {
      const pos1 = positions.get(conflict.course1Id);
      const pos2 = positions.get(conflict.course2Id);
      if (!pos1 || !pos2) return;

      const style = CONFLICT_TYPE_COLORS[conflict.type];
      const isHighlighted = 
        hoveredCourse === conflict.course1Id || 
        hoveredCourse === conflict.course2Id ||
        selectedCourseId === conflict.course1Id ||
        selectedCourseId === conflict.course2Id;

      ctx.beginPath();
      ctx.strokeStyle = style.stroke;
      ctx.lineWidth = isHighlighted ? 3 : 2;
      ctx.globalAlpha = isHighlighted ? 1 : 0.6;
      
      if (style.dash !== "0") {
        ctx.setLineDash(style.dash.split(",").map(Number));
      } else {
        ctx.setLineDash([]);
      }
      
      ctx.moveTo(pos1.x, pos1.y);
      ctx.lineTo(pos2.x, pos2.y);
      ctx.stroke();
      ctx.globalAlpha = 1;
    });

    ctx.setLineDash([]);

    courses.forEach((course) => {
      const pos = positions.get(course.id);
      if (!pos) return;

      const assignment = assignments.find((a) => a.courseId === course.id);
      const color = assignment ? getColorForTimeSlot(assignment.timeSlot) : null;
      const isSelected = selectedCourseId === course.id;
      const isHovered = hoveredCourse === course.id;

      ctx.beginPath();
      ctx.arc(pos.x, pos.y, NODE_RADIUS, 0, Math.PI * 2);
      
      if (color) {
        ctx.fillStyle = color.bg;
      } else {
        ctx.fillStyle = "hsl(210, 10%, 85%)";
      }
      ctx.fill();

      if (isSelected || isHovered) {
        ctx.strokeStyle = isSelected ? "hsl(217, 91%, 48%)" : "hsl(210, 10%, 60%)";
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      ctx.fillStyle = color ? color.text : "#333";
      ctx.font = "bold 14px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(course.code, pos.x, pos.y);

      if (assignment) {
        ctx.font = "11px Inter, sans-serif";
        ctx.fillStyle = color ? color.text : "#666";
        ctx.fillText(`T${assignment.timeSlot}`, pos.x, pos.y + 16);
      }
    });

    ctx.restore();
  }, [courses, conflicts, positions, assignments, zoom, offset, hoveredCourse, selectedCourseId]);

  useEffect(() => {
    draw();
  }, [draw]);

  const getMousePos = (e: React.MouseEvent): { x: number; y: number } => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    return {
      x: (e.clientX - rect.left - offset.x) / zoom,
      y: (e.clientY - rect.top - offset.y) / zoom,
    };
  };

  const findCourseAtPosition = (x: number, y: number): Course | null => {
    for (const course of courses) {
      const pos = positions.get(course.id);
      if (!pos) continue;
      const dx = x - pos.x;
      const dy = y - pos.y;
      if (dx * dx + dy * dy <= NODE_RADIUS * NODE_RADIUS) {
        return course;
      }
    }
    return null;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    const { x, y } = getMousePos(e);
    const course = findCourseAtPosition(x, y);
    
    if (course) {
      setDraggingNode(course.id);
      onSelectCourse(course);
    } else {
      setIsDragging(true);
      setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const { x, y } = getMousePos(e);
    
    if (draggingNode) {
      setPositions((prev) => {
        const newPositions = new Map(prev);
        const pos = newPositions.get(draggingNode);
        if (pos) {
          pos.x = x;
          pos.y = y;
          pos.vx = 0;
          pos.vy = 0;
        }
        return newPositions;
      });
    } else if (isDragging) {
      setOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    } else {
      const course = findCourseAtPosition(x, y);
      setHoveredCourse(course?.id || null);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDraggingNode(null);
  };

  const handleZoomIn = () => setZoom((z) => Math.min(z * 1.2, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z / 1.2, 0.3));
  const handleReset = () => {
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    initializePositions();
  };

  return (
    <Card className="relative flex flex-col h-full overflow-hidden">
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        <div className="flex gap-1">
          <Button size="icon" variant="secondary" onClick={handleZoomIn} data-testid="button-zoom-in">
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="secondary" onClick={handleZoomOut} data-testid="button-zoom-out">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="secondary" onClick={handleReset} data-testid="button-reset-view">
            <Maximize2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="absolute top-4 right-4 z-10 bg-card/90 backdrop-blur-sm rounded-lg p-3 border border-card-border">
        <h4 className="text-xs font-semibold text-muted-foreground mb-2">Conflict Types</h4>
        <div className="flex flex-col gap-1.5">
          {Object.entries(CONFLICT_TYPE_COLORS).map(([type, style]) => (
            <div key={type} className="flex items-center gap-2">
              <svg width="24" height="4">
                <line
                  x1="0"
                  y1="2"
                  x2="24"
                  y2="2"
                  stroke={style.stroke}
                  strokeWidth="2"
                  strokeDasharray={style.dash}
                />
              </svg>
              <span className="text-xs text-muted-foreground">
                {CONFLICT_TYPE_LABELS[type]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {courses.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/20">
          <div className="text-center p-8">
            <Move className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground text-lg font-medium">No courses yet</p>
            <p className="text-muted-foreground/70 text-sm mt-1">
              Add courses to see the conflict graph
            </p>
          </div>
        </div>
      )}

      <div ref={containerRef} className="flex-1 min-h-[500px]">
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="cursor-grab active:cursor-grabbing"
          style={{ display: "block" }}
          data-testid="canvas-graph"
        />
      </div>

      {hoveredCourse && (
        <div className="absolute bottom-4 left-4 z-10">
          <Badge variant="secondary" className="text-sm">
            {courses.find((c) => c.id === hoveredCourse)?.name || hoveredCourse}
          </Badge>
        </div>
      )}
    </Card>
  );
}
