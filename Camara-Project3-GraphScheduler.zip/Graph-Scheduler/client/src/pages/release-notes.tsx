import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  ArrowLeft,
  FileText,
  Sparkles,
  Bug,
  Wrench,
  Rocket,
  Zap,
  Shield,
  Palette
} from "lucide-react";

interface ReleaseNote {
  version: string;
  date: string;
  type: "major" | "minor" | "patch";
  highlights: string[];
  features?: { icon: typeof Sparkles; title: string; description: string }[];
  improvements?: string[];
  bugfixes?: string[];
}

const releases: ReleaseNote[] = [
  {
    version: "1.2.0",
    date: "December 19, 2024",
    type: "minor",
    highlights: [
      "Enhanced UI with elegant white background design",
      "Added technical documentation and release notes pages",
      "Improved export functionality with RFC4180 CSV compliance"
    ],
    features: [
      {
        icon: Palette,
        title: "Refined Visual Design",
        description: "New elegant white background with emerald green accent color scheme, refined shadows, smooth scrollbars, and subtle gradients for a premium look and feel."
      },
      {
        icon: FileText,
        title: "Technical Documentation",
        description: "Comprehensive documentation covering system architecture, algorithm details, API reference, and data models."
      },
      {
        icon: Sparkles,
        title: "Release Notes",
        description: "Version history and changelog to track all updates and improvements."
      }
    ],
    improvements: [
      "CSV export now properly escapes quotes and commas per RFC4180 standard",
      "PDF export includes fallback download when popup is blocked",
      "Semester schema now correctly handles optional date fields"
    ],
    bugfixes: [
      "Fixed semester creation failing due to required date validation",
      "Fixed CSV malformed output when fields contain special characters",
      "Resolved PDF print window not opening in some browsers"
    ]
  },
  {
    version: "1.1.0",
    date: "December 18, 2024",
    type: "minor",
    highlights: [
      "Multiple graph coloring algorithms with performance comparison",
      "Semester/term management functionality",
      "PDF and CSV export capabilities"
    ],
    features: [
      {
        icon: Zap,
        title: "Algorithm Selection",
        description: "Choose between Greedy, Welsh-Powell, DSatur, and Backtracking algorithms with real-time performance metrics display."
      },
      {
        icon: Rocket,
        title: "Semester Management",
        description: "Create, switch, and delete academic semesters with active semester indicator and semester-specific scheduling."
      },
      {
        icon: FileText,
        title: "Export Functionality",
        description: "Export generated schedules to CSV for spreadsheet analysis or PDF for printing and sharing."
      }
    ],
    improvements: [
      "Algorithm selector shows execution time in milliseconds",
      "Statistics panel displays chromatic number and assignment counts",
      "Improved form validation with better error messages"
    ]
  },
  {
    version: "1.0.0",
    date: "December 17, 2024",
    type: "major",
    highlights: [
      "Initial release of GraphScheduler",
      "Core graph coloring scheduling engine",
      "Interactive course and conflict management"
    ],
    features: [
      {
        icon: Shield,
        title: "Graph Coloring Engine",
        description: "Core scheduling algorithm using graph coloring to assign time slots without conflicts between courses."
      },
      {
        icon: Wrench,
        title: "Course Management",
        description: "Add, edit, and delete courses with professor, students, and preferred room assignments."
      },
      {
        icon: Bug,
        title: "Conflict Detection",
        description: "Define and visualize conflicts between courses including professor conflicts, room conflicts, and student overlaps."
      },
      {
        icon: Sparkles,
        title: "Room Allocation",
        description: "Automatic room assignment based on availability and capacity constraints."
      }
    ],
    improvements: [
      "Interactive graph visualization with color-coded nodes",
      "Real-time schedule generation with conflict validation",
      "Responsive design with dark/light theme support"
    ]
  }
];

function getVersionBadgeVariant(type: ReleaseNote["type"]) {
  switch (type) {
    case "major": return "default";
    case "minor": return "secondary";
    case "patch": return "outline";
  }
}

export default function ReleaseNotes() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Scheduler
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold" data-testid="text-release-title">Release Notes</h1>
          </div>
        </div>
      </header>

      <main className="container py-8 max-w-4xl">
        <div className="mb-8">
          <h2 className="text-3xl font-bold tracking-tight mb-2">Version History</h2>
          <p className="text-muted-foreground text-lg">
            Track all updates, new features, and improvements to GraphScheduler
          </p>
        </div>

        <div className="space-y-8">
          {releases.map((release, index) => (
            <Card key={release.version} className={index === 0 ? "border-primary/30" : ""}>
              <CardHeader>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-2xl" data-testid={`text-version-${release.version}`}>
                      v{release.version}
                    </CardTitle>
                    <Badge variant={getVersionBadgeVariant(release.type)}>
                      {release.type}
                    </Badge>
                    {index === 0 && (
                      <Badge className="bg-primary/10 text-primary border-primary/20">
                        Latest
                      </Badge>
                    )}
                  </div>
                  <span className="text-sm text-muted-foreground">{release.date}</span>
                </div>
                <div className="mt-4 space-y-1">
                  {release.highlights.map((highlight, i) => (
                    <p key={i} className="text-muted-foreground flex items-center gap-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
                      {highlight}
                    </p>
                  ))}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {release.features && release.features.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" />
                      New Features
                    </h4>
                    <div className="grid gap-3">
                      {release.features.map((feature, i) => (
                        <div key={i} className="rounded-lg border p-4 bg-muted/30">
                          <div className="flex items-center gap-2 mb-2">
                            <feature.icon className="h-4 w-4 text-primary" />
                            <span className="font-medium">{feature.title}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{feature.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {release.improvements && release.improvements.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Wrench className="h-4 w-4 text-blue-500" />
                      Improvements
                    </h4>
                    <ul className="space-y-2">
                      {release.improvements.map((item, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                          <span className="h-1.5 w-1.5 rounded-full bg-blue-500 mt-2 shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {release.bugfixes && release.bugfixes.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Bug className="h-4 w-4 text-orange-500" />
                      Bug Fixes
                    </h4>
                    <ul className="space-y-2">
                      {release.bugfixes.map((item, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                          <span className="h-1.5 w-1.5 rounded-full bg-orange-500 mt-2 shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>GraphScheduler - Course Scheduling with Graph Coloring</p>
          <p className="mt-1">Built with React, Express, and advanced graph algorithms</p>
        </div>
      </main>
    </div>
  );
}
