import type { Course, Conflict, Room, ScheduleResult, ScheduleAssignment, AlgorithmType } from "@shared/schema";
import { getColorForTimeSlot } from "./color-utils";

interface AdjacencyList {
  [courseId: string]: Set<string>;
}

function buildAdjacencyList(courses: Course[], conflicts: Conflict[]): AdjacencyList {
  const adjacencyList: AdjacencyList = {};

  for (const course of courses) {
    adjacencyList[course.id] = new Set();
  }

  for (const conflict of conflicts) {
    if (adjacencyList[conflict.course1Id] && adjacencyList[conflict.course2Id]) {
      adjacencyList[conflict.course1Id].add(conflict.course2Id);
      adjacencyList[conflict.course2Id].add(conflict.course1Id);
    }
  }

  return adjacencyList;
}

function buildPrerequisiteGraph(courses: Course[], conflicts: Conflict[]): Map<string, Set<string>> {
  const prereqGraph = new Map<string, Set<string>>();
  
  for (const course of courses) {
    prereqGraph.set(course.id, new Set());
  }
  
  for (const conflict of conflicts) {
    if (conflict.type === "prerequisite") {
      const deps = prereqGraph.get(conflict.course2Id);
      if (deps) {
        deps.add(conflict.course1Id);
      }
    }
  }
  
  return prereqGraph;
}

function topologicalSort(courses: Course[], prereqGraph: Map<string, Set<string>>): { order: string[]; hasCycle: boolean; cycleNodes: string[] } {
  const visited = new Set<string>();
  const inStack = new Set<string>();
  const order: string[] = [];
  let hasCycle = false;
  const cycleNodes: string[] = [];
  
  function dfs(nodeId: string): boolean {
    if (inStack.has(nodeId)) {
      hasCycle = true;
      return false;
    }
    if (visited.has(nodeId)) {
      return true;
    }
    
    visited.add(nodeId);
    inStack.add(nodeId);
    
    const deps = prereqGraph.get(nodeId) || new Set();
    for (const dep of Array.from(deps)) {
      if (!dfs(dep)) {
        cycleNodes.push(nodeId);
        return false;
      }
    }
    
    inStack.delete(nodeId);
    order.push(nodeId);
    return true;
  }
  
  for (const course of courses) {
    if (!visited.has(course.id)) {
      dfs(course.id);
    }
  }
  
  return { order, hasCycle, cycleNodes };
}

function validatePrerequisites(
  assignments: { courseId: string; timeSlot: number }[],
  conflicts: Conflict[],
  courses: Course[]
): string[] {
  const errors: string[] = [];
  const courseMap = new Map(courses.map(c => [c.id, c]));
  const assignmentMap = new Map(assignments.map(a => [a.courseId, a.timeSlot]));
  
  for (const conflict of conflicts) {
    if (conflict.type === "prerequisite") {
      const prereqSlot = assignmentMap.get(conflict.course1Id);
      const courseSlot = assignmentMap.get(conflict.course2Id);
      
      if (prereqSlot !== undefined && courseSlot !== undefined) {
        if (prereqSlot >= courseSlot) {
          const prereqCourse = courseMap.get(conflict.course1Id);
          const course = courseMap.get(conflict.course2Id);
          errors.push(
            `${prereqCourse?.code || conflict.course1Id} must be scheduled before ${course?.code || conflict.course2Id} (prerequisite constraint)`
          );
        }
      }
    }
  }
  
  return errors;
}

function greedyColoring(
  courses: Course[],
  adjacencyList: AdjacencyList
): Map<string, number> {
  const colorAssignment = new Map<string, number>();

  const sortedCourses = [...courses].sort((a, b) => {
    const degreeA = adjacencyList[a.id]?.size || 0;
    const degreeB = adjacencyList[b.id]?.size || 0;
    return degreeB - degreeA;
  });

  for (const course of sortedCourses) {
    const neighbors = adjacencyList[course.id] || new Set();
    const usedColors = new Set<number>();

    for (const neighborId of Array.from(neighbors)) {
      const neighborColor = colorAssignment.get(neighborId);
      if (neighborColor !== undefined) {
        usedColors.add(neighborColor);
      }
    }

    let color = 0;
    while (usedColors.has(color)) {
      color++;
    }

    colorAssignment.set(course.id, color);
  }

  return colorAssignment;
}

function welshPowellColoring(
  courses: Course[],
  adjacencyList: AdjacencyList
): Map<string, number> {
  const colorAssignment = new Map<string, number>();
  
  const sortedCourses = [...courses].sort((a, b) => {
    const degreeA = adjacencyList[a.id]?.size || 0;
    const degreeB = adjacencyList[b.id]?.size || 0;
    return degreeB - degreeA;
  });
  
  let currentColor = 0;
  const colored = new Set<string>();
  
  while (colored.size < courses.length) {
    for (const course of sortedCourses) {
      if (colored.has(course.id)) continue;
      
      const neighbors = adjacencyList[course.id] || new Set();
      let canColor = true;
      
      for (const neighborId of Array.from(neighbors)) {
        if (colorAssignment.get(neighborId) === currentColor) {
          canColor = false;
          break;
        }
      }
      
      if (canColor) {
        colorAssignment.set(course.id, currentColor);
        colored.add(course.id);
      }
    }
    currentColor++;
  }
  
  return colorAssignment;
}

function dsaturColoring(
  courses: Course[],
  adjacencyList: AdjacencyList
): Map<string, number> {
  const colorAssignment = new Map<string, number>();
  const saturation = new Map<string, Set<number>>();
  
  for (const course of courses) {
    saturation.set(course.id, new Set());
  }
  
  while (colorAssignment.size < courses.length) {
    let maxSat = -1;
    let maxDegree = -1;
    let selectedCourse: Course | null = null;
    
    for (const course of courses) {
      if (colorAssignment.has(course.id)) continue;
      
      const sat = saturation.get(course.id)?.size || 0;
      const degree = adjacencyList[course.id]?.size || 0;
      
      if (sat > maxSat || (sat === maxSat && degree > maxDegree)) {
        maxSat = sat;
        maxDegree = degree;
        selectedCourse = course;
      }
    }
    
    if (!selectedCourse) break;
    
    const neighbors = adjacencyList[selectedCourse.id] || new Set();
    const usedColors = new Set<number>();
    
    for (const neighborId of Array.from(neighbors)) {
      const neighborColor = colorAssignment.get(neighborId);
      if (neighborColor !== undefined) {
        usedColors.add(neighborColor);
      }
    }
    
    let color = 0;
    while (usedColors.has(color)) {
      color++;
    }
    
    colorAssignment.set(selectedCourse.id, color);
    
    for (const neighborId of Array.from(neighbors)) {
      const neighborSat = saturation.get(neighborId);
      if (neighborSat) {
        neighborSat.add(color);
      }
    }
  }
  
  return colorAssignment;
}

function backtrackingColoring(
  courses: Course[],
  adjacencyList: AdjacencyList,
  maxColors: number = 20
): Map<string, number> | null {
  const colorAssignment = new Map<string, number>();
  const courseIds = courses.map(c => c.id);
  
  function isValid(courseId: string, color: number): boolean {
    const neighbors = adjacencyList[courseId] || new Set();
    for (const neighborId of Array.from(neighbors)) {
      if (colorAssignment.get(neighborId) === color) {
        return false;
      }
    }
    return true;
  }
  
  function solve(index: number, numColors: number): boolean {
    if (index === courseIds.length) {
      return true;
    }
    
    const courseId = courseIds[index];
    
    for (let color = 0; color < numColors; color++) {
      if (isValid(courseId, color)) {
        colorAssignment.set(courseId, color);
        if (solve(index + 1, numColors)) {
          return true;
        }
        colorAssignment.delete(courseId);
      }
    }
    
    return false;
  }
  
  for (let numColors = 1; numColors <= maxColors; numColors++) {
    colorAssignment.clear();
    if (solve(0, numColors)) {
      return colorAssignment;
    }
  }
  
  return greedyColoring(courses, adjacencyList);
}

function assignRooms(
  assignments: { courseId: string; timeSlot: number }[],
  rooms: Room[]
): Map<string, string> {
  const roomAssignment = new Map<string, string>();

  if (rooms.length === 0) {
    return roomAssignment;
  }

  const roomsByTimeSlot = new Map<number, Set<string>>();

  for (const assignment of assignments) {
    const { courseId, timeSlot } = assignment;

    if (!roomsByTimeSlot.has(timeSlot)) {
      roomsByTimeSlot.set(timeSlot, new Set());
    }

    const usedRooms = roomsByTimeSlot.get(timeSlot)!;

    for (const room of rooms) {
      if (!usedRooms.has(room.id)) {
        roomAssignment.set(courseId, room.id);
        usedRooms.add(room.id);
        break;
      }
    }
  }

  return roomAssignment;
}

export function generateSchedule(
  courses: Course[],
  conflicts: Conflict[],
  rooms: Room[],
  algorithm: AlgorithmType = "greedy"
): ScheduleResult {
  const startTime = performance.now();
  
  if (courses.length === 0) {
    return {
      assignments: [],
      chromaticNumber: 0,
      totalTimeSlots: 0,
      algorithm,
      executionTimeMs: 0,
      validationErrors: [],
    };
  }

  const prereqGraph = buildPrerequisiteGraph(courses, conflicts);
  const { order: topologicalOrder, hasCycle, cycleNodes } = topologicalSort(courses, prereqGraph);
  
  const validationErrors: string[] = [];
  if (hasCycle) {
    validationErrors.push(`Circular prerequisite dependency detected involving courses: ${cycleNodes.join(", ")}`);
  }

  const adjacencyList = buildAdjacencyList(courses, conflicts);
  
  let colorAssignment: Map<string, number>;
  
  switch (algorithm) {
    case "welsh-powell":
      colorAssignment = welshPowellColoring(courses, adjacencyList);
      break;
    case "dsatur":
      colorAssignment = dsaturColoring(courses, adjacencyList);
      break;
    case "backtracking":
      colorAssignment = backtrackingColoring(courses, adjacencyList) || greedyColoring(courses, adjacencyList);
      break;
    case "greedy":
    default:
      colorAssignment = greedyColoring(courses, adjacencyList);
      break;
  }

  const basicAssignments = courses.map((course) => ({
    courseId: course.id,
    timeSlot: colorAssignment.get(course.id) || 0,
  }));

  const prereqErrors = validatePrerequisites(basicAssignments, conflicts, courses);
  validationErrors.push(...prereqErrors);

  const roomAssignment = assignRooms(basicAssignments, rooms);

  const assignments: ScheduleAssignment[] = basicAssignments.map((a) => ({
    courseId: a.courseId,
    timeSlot: a.timeSlot,
    roomId: roomAssignment.get(a.courseId),
    color: getColorForTimeSlot(a.timeSlot),
  }));

  const maxColor = Math.max(...Array.from(colorAssignment.values()), -1);
  const chromaticNumber = maxColor + 1;
  
  const endTime = performance.now();

  return {
    assignments,
    chromaticNumber,
    totalTimeSlots: chromaticNumber,
    algorithm,
    executionTimeMs: Math.round((endTime - startTime) * 100) / 100,
    validationErrors: validationErrors.length > 0 ? validationErrors : undefined,
    topologicalOrder: !hasCycle ? topologicalOrder : undefined,
  };
}

export function addCourseToSchedule(
  existingResult: ScheduleResult,
  newCourse: Course,
  conflicts: Conflict[],
  rooms: Room[],
  allCourses: Course[]
): ScheduleResult {
  const adjacencyList = buildAdjacencyList(allCourses, conflicts);

  const neighbors = adjacencyList[newCourse.id] || new Set();
  const usedColors = new Set<number>();

  for (const assignment of existingResult.assignments) {
    if (neighbors.has(assignment.courseId)) {
      usedColors.add(assignment.timeSlot);
    }
  }

  let newColor = 0;
  while (usedColors.has(newColor)) {
    newColor++;
  }

  const roomsByTimeSlot = new Map<number, Set<string>>();
  for (const assignment of existingResult.assignments) {
    if (!roomsByTimeSlot.has(assignment.timeSlot)) {
      roomsByTimeSlot.set(assignment.timeSlot, new Set());
    }
    if (assignment.roomId) {
      roomsByTimeSlot.get(assignment.timeSlot)!.add(assignment.roomId);
    }
  }

  let assignedRoom: string | undefined;
  if (!roomsByTimeSlot.has(newColor)) {
    roomsByTimeSlot.set(newColor, new Set());
  }
  const usedRooms = roomsByTimeSlot.get(newColor)!;

  for (const room of rooms) {
    if (!usedRooms.has(room.id)) {
      assignedRoom = room.id;
      break;
    }
  }

  const newAssignment: ScheduleAssignment = {
    courseId: newCourse.id,
    timeSlot: newColor,
    roomId: assignedRoom,
    color: getColorForTimeSlot(newColor),
  };

  const newAssignments = [...existingResult.assignments, newAssignment];
  const maxColor = Math.max(...newAssignments.map((a) => a.timeSlot), -1);

  const prereqErrors = validatePrerequisites(
    newAssignments.map(a => ({ courseId: a.courseId, timeSlot: a.timeSlot })),
    conflicts,
    allCourses
  );

  return {
    assignments: newAssignments,
    chromaticNumber: maxColor + 1,
    totalTimeSlots: maxColor + 1,
    algorithm: existingResult.algorithm || "greedy",
    validationErrors: prereqErrors.length > 0 ? prereqErrors : undefined,
  };
}
